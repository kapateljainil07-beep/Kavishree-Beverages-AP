package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BeverageItem
import java.util.Locale

@Composable
fun InventoryScreen(
    beverages: List<BeverageItem>,
    selectedCategory: String,
    searchQuery: String,
    onCategorySelected: (String) -> Unit,
    onSearchChanged: (String) -> Unit,
    onAddBeverage: (name: String, category: String, price: Double, stock: Int, unit: String, barcode: String, isSoda: Boolean, desc: String) -> Unit,
    onUpdatePriceAndStock: (id: Long, price: Double, stock: Int) -> Unit = { _, _, _ -> },
    onUpdateBeverageItem: (BeverageItem) -> Unit = { item -> onUpdatePriceAndStock(item.id, item.price, item.stockQuantity) },
    onRemoveBeverage: (BeverageItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddItemDialog by remember { mutableStateOf(false) }
    var itemToEdit by remember { mutableStateOf<BeverageItem?>(null) }
    var itemToDelete by remember { mutableStateOf<BeverageItem?>(null) }
    var isAddingPresetSoda by remember { mutableStateOf(false) }
    var isAddingPresetWaterBox by remember { mutableStateOf(false) }

    val categories = listOf("All", "Soda", "Water Box", "Cold Drink", "Juice", "Water")

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header with Quick Add Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Inventory,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Inventory & Pricing",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${beverages.size} Products • Manage Sodas & Drinks",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Quick Add Soda Shortcut button ("And Soda Item Add And Remove Option")
                    Button(
                        onClick = {
                            isAddingPresetSoda = true
                            isAddingPresetWaterBox = false
                            showAddItemDialog = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        ),
                        modifier = Modifier.testTag("add_soda_quick_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text("+ Soda", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Quick Add Water Box Shortcut button ("Add on Water Box on Items")
                    Button(
                        onClick = {
                            isAddingPresetWaterBox = true
                            isAddingPresetSoda = false
                            showAddItemDialog = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0288D1)
                        ),
                        modifier = Modifier.testTag("add_water_box_quick_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text("+ Water Box", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChanged,
                placeholder = { Text("Search by name, category, or barcode...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChanged("") }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("inventory_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Category Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onCategorySelected(cat) }
                            .testTag("inventory_category_$cat")
                    ) {
                        Text(
                            text = if (cat == "Soda") "🥤 Sodas" else cat,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // List of Items
            if (beverages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "📦", fontSize = 42.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No items in this category",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(onClick = { showAddItemDialog = true }) {
                            Text("Add New Item")
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 72.dp)
                ) {
                    items(beverages, key = { it.id }) { item ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("inventory_item_${item.id}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (item.isSoda) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(if (item.isSoda) "🥤" else "🍹", fontSize = 22.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.name,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        if (item.isSoda) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                                            ) {
                                                Text(
                                                    text = "Soda",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        color = MaterialTheme.colorScheme.secondary,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold
                                                    ),
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Text(
                                        text = "Price: ₹${String.format(Locale.US, "%.2f", item.price)} / ${item.unit} • Stock: ${item.stockQuantity}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (item.stockQuantity <= 15) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )

                                    if (item.barcode.isNotBlank()) {
                                        Text(
                                            text = "Barcode: ${item.barcode}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }

                                // Quick Change Details button ("Items Name And Items Quantity All Details Are Changes Option")
                                IconButton(
                                    onClick = { itemToEdit = item },
                                    modifier = Modifier.testTag("edit_pricing_${item.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Item Details",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }

                                // Remove Item button ("All Iteam Add And Remove Option")
                                IconButton(
                                    onClick = { itemToDelete = item },
                                    modifier = Modifier.testTag("delete_item_${item.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Remove Item",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // FAB to Add New Item
        FloatingActionButton(
            onClick = {
                isAddingPresetSoda = false
                showAddItemDialog = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_item_fab")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Item")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Item", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Add Beverage / Soda / Water Box Item Dialog
    if (showAddItemDialog) {
        var name by remember {
            mutableStateOf(
                when {
                    isAddingPresetWaterBox -> "Premium Water Box "
                    isAddingPresetSoda -> "Fresh "
                    else -> ""
                }
            )
        }
        var category by remember {
            mutableStateOf(
                when {
                    isAddingPresetWaterBox -> "Water Box"
                    isAddingPresetSoda -> "Soda"
                    else -> "Soda"
                }
            )
        }
        var priceText by remember {
            mutableStateOf(
                when {
                    isAddingPresetWaterBox -> "80"
                    isAddingPresetSoda -> "25"
                    else -> "20"
                }
            )
        }
        var stockText by remember { mutableStateOf("100") }
        var unit by remember {
            mutableStateOf(
                when {
                    isAddingPresetWaterBox -> "Box"
                    isAddingPresetSoda -> "Bottle"
                    else -> "Bottle"
                }
            )
        }
        var barcode by remember {
            mutableStateOf(
                when {
                    isAddingPresetWaterBox -> "WB-" + (100 + (System.currentTimeMillis() % 900))
                    isAddingPresetSoda -> "SODA-" + (10 + (System.currentTimeMillis() % 90))
                    else -> ""
                }
            )
        }
        var isSoda by remember { mutableStateOf(isAddingPresetSoda) }
        var desc by remember {
            mutableStateOf(
                if (isAddingPresetWaterBox) "Sealed Pure Mineral Water Carton Box" else ""
            )
        }
        var error by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showAddItemDialog = false },
            title = {
                Text(
                    text = when {
                        isAddingPresetWaterBox -> "Add Water Box Item"
                        isAddingPresetSoda -> "Add New Soda Flavor"
                        else -> "Add New Item"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Item / Soda Name") },
                        placeholder = { Text("e.g. Jeera Soda, Orange Punch") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_item_name_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { priceText = it },
                            label = { Text("Price (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("new_item_price_input")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedTextField(
                            value = stockText,
                            onValueChange = { stockText = it },
                            label = { Text("Stock Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("new_item_stock_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("Category") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text("Unit") },
                            placeholder = { Text("Bottle/Glass") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text("Barcode / SKU (Optional)") },
                        placeholder = { Text("e.g. SODA-10") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isSoda = !isSoda }
                    ) {
                        Checkbox(
                            checked = isSoda,
                            onCheckedChange = { isSoda = it },
                            modifier = Modifier.testTag("new_item_is_soda_checkbox")
                        )
                        Text(
                            text = "Mark as Soda Beverage (Quick POS Display)",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    if (error != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = priceText.toDoubleOrNull()
                        val s = stockText.toIntOrNull()
                        if (name.isBlank()) {
                            error = "Please enter an item name"
                            return@Button
                        }
                        if (p == null || p <= 0) {
                            error = "Please enter a valid price"
                            return@Button
                        }
                        if (s == null || s < 0) {
                            error = "Please enter a valid stock quantity"
                            return@Button
                        }

                        onAddBeverage(name, category, p, s, unit, barcode, isSoda, desc)
                        showAddItemDialog = false
                    },
                    modifier = Modifier.testTag("save_new_item_button")
                ) {
                    Text("Save Item")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddItemDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Full Item Edit Dialog ("Items Name And Items Quantity All Details Are Changes Option Give To Add On App")
    if (itemToEdit != null) {
        val itm = itemToEdit!!
        var editName by remember { mutableStateOf(itm.name) }
        var editCategory by remember { mutableStateOf(itm.category) }
        var editPriceText by remember { mutableStateOf(itm.price.toString()) }
        var editStockText by remember { mutableStateOf(itm.stockQuantity.toString()) }
        var editUnit by remember { mutableStateOf(itm.unit) }
        var editBarcode by remember { mutableStateOf(itm.barcode) }
        var editIsSoda by remember { mutableStateOf(itm.isSoda) }
        var editDesc by remember { mutableStateOf(itm.description) }
        var editError by remember { mutableStateOf<String?>(null) }

        val editCategories = listOf("Soda", "Water Box", "Cold Drink", "Juice", "Water", "Snack")
        val editUnits = listOf("Bottle", "Box", "Can", "Glass", "Pouch", "Pack")

        AlertDialog(
            onDismissRequest = { itemToEdit = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Edit Item Details",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Modify Item Name, Stock Quantity, Price & All Details",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 1. Item Name
                    OutlinedTextField(
                        value = editName,
                        onValueChange = {
                            editName = it
                            editError = null
                        },
                        label = { Text("Item Name *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_item_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2. Category Selector
                    Text(
                        text = "Category:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(editCategories) { cat ->
                            val isSelected = editCategory == cat
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        editCategory = cat
                                        if (cat == "Soda") editIsSoda = true
                                        if (cat == "Water Box") {
                                            editIsSoda = false
                                            editUnit = "Box"
                                        }
                                    }
                            ) {
                                Text(
                                    text = cat,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3. Price and Stock Quantity
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = editPriceText,
                            onValueChange = {
                                editPriceText = it
                                editError = null
                            },
                            label = { Text("Price (₹) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("edit_price_input")
                        )

                        OutlinedTextField(
                            value = editStockText,
                            onValueChange = {
                                editStockText = it
                                editError = null
                            },
                            label = { Text("Quantity *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("edit_stock_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Quick Quantity Adjust Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Quick Adjust:",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp)
                        )
                        val adjustments = listOf(-10, -1, +1, +10)
                        adjustments.forEach { delta ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable {
                                        val current = editStockText.toIntOrNull() ?: 0
                                        val next = maxOf(0, current + delta)
                                        editStockText = next.toString()
                                    }
                            ) {
                                Text(
                                    text = if (delta > 0) "+$delta" else "$delta",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 4. Unit Selector
                    Text(
                        text = "Unit:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(editUnits) { u ->
                            val isSelected = editUnit == u
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { editUnit = u }
                            ) {
                                Text(
                                    text = u,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSelected) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 5. Barcode / SKU
                    OutlinedTextField(
                        value = editBarcode,
                        onValueChange = { editBarcode = it },
                        label = { Text("Barcode / Item Code") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_barcode_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 6. Description / Details
                    OutlinedTextField(
                        value = editDesc,
                        onValueChange = { editDesc = it },
                        label = { Text("Item Details / Notes") },
                        maxLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_details_input")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // 7. Is Soda Checkbox
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { editIsSoda = !editIsSoda }
                    ) {
                        Checkbox(
                            checked = editIsSoda,
                            onCheckedChange = { editIsSoda = it }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Item is a Carbonated Soda / Fountain Drink",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    if (editError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = editError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val np = editPriceText.toDoubleOrNull()
                        val ns = editStockText.toIntOrNull()
                        if (editName.isBlank()) {
                            editError = "Please enter an item name"
                            return@Button
                        }
                        if (np == null || np <= 0) {
                            editError = "Please enter a valid price"
                            return@Button
                        }
                        if (ns == null || ns < 0) {
                            editError = "Please enter a valid quantity"
                            return@Button
                        }

                        val updated = itm.copy(
                            name = editName.trim(),
                            category = editCategory.trim(),
                            price = np,
                            stockQuantity = ns,
                            unit = editUnit.trim(),
                            barcode = editBarcode.trim(),
                            isSoda = editIsSoda || editCategory.equals("Soda", ignoreCase = true),
                            description = editDesc.trim()
                        )
                        onUpdateBeverageItem(updated)
                        itemToEdit = null
                    },
                    modifier = Modifier.testTag("save_edited_item_button")
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToEdit = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Confirm Delete Item Dialog ("All Iteam Add And Remove Option")
    if (itemToDelete != null) {
        val itm = itemToDelete!!
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = {
                Text("Remove '${itm.name}'?")
            },
            text = {
                Text("Are you sure you want to remove this item from inventory? It will no longer appear on POS.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRemoveBeverage(itm)
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_item_button")
                ) {
                    Text("Remove")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
