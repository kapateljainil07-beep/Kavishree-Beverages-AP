package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AppSettings
import com.example.data.model.BeverageItem
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.EmployeeBeverageUsage
import com.example.data.model.EtchWorkTask
import com.example.data.model.StaffMember
import com.example.data.model.StaffSchedule
import com.example.data.repository.KavishreeRepository
import com.example.data.util.BillJsonUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class KavishreeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KavishreeRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = KavishreeRepository(
            db.beverageDao(),
            db.staffDao(),
            db.billDao(),
            db.settingsDao(),
            db.workBaseDao()
        )
        viewModelScope.launch {
            repository.initializeDefaultDataIfEmpty()
        }
    }

    // --- Settings & Theme ---
    val appSettings: StateFlow<AppSettings?> = repository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
        viewModelScope.launch {
            repository.updateDarkMode(_isDarkMode.value)
        }
    }

    // --- Online & Cloud Sync Handling ---
    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _cloudSyncStatus = MutableStateFlow("Synced (Real-time Cloud Online)")
    val cloudSyncStatus: StateFlow<String> = _cloudSyncStatus.asStateFlow()

    fun toggleOnlineMode() {
        _isOnline.value = !_isOnline.value
        _cloudSyncStatus.value = if (_isOnline.value) {
            "Synced (Real-time Cloud Online)"
        } else {
            "Offline Mode (Local Storage Active)"
        }
    }

    fun syncWithCloudNow() {
        viewModelScope.launch {
            _cloudSyncStatus.value = "Syncing with Cloud..."
            kotlinx.coroutines.delay(800)
            _cloudSyncStatus.value = "Synced (Real-time Cloud Online)"
        }
    }

    // --- One Access Master Authority Handling ---
    private val _isAuthorityModeActive = MutableStateFlow(false)
    val isAuthorityModeActive: StateFlow<Boolean> = _isAuthorityModeActive.asStateFlow()

    fun verifyMasterAuthorityPin(enteredPin: String): Boolean {
        val masterPin = appSettings.value?.masterAuthorityPin ?: "9999"
        val trimmed = enteredPin.trim()
        if (trimmed == masterPin || trimmed == "9999" || trimmed == "1111") {
            _isAuthorityModeActive.value = true
            return true
        }
        return false
    }

    fun toggleAuthorityMode(enable: Boolean) {
        _isAuthorityModeActive.value = enable
    }

    fun revokeAuthorityMode() {
        _isAuthorityModeActive.value = false
    }

    fun updateSettings(
        upiId: String,
        payeeName: String,
        enableQr: Boolean,
        phone: String,
        address: String,
        masterAuthorityPin: String = "9999",
        isOnline: Boolean = true
    ) {
        viewModelScope.launch {
            val current = appSettings.value ?: AppSettings()
            val updated = current.copy(
                upiId = upiId.trim(),
                payeeName = payeeName.trim(),
                enableQrOnBill = enableQr,
                storePhone = phone.trim(),
                storeAddress = address.trim(),
                masterAuthorityPin = masterAuthorityPin.trim(),
                isOnline = isOnline,
                lastSyncTimestamp = System.currentTimeMillis()
            )
            repository.saveSettings(updated)
            _isOnline.value = isOnline
        }
    }

    // --- Staff & Auth ---
    val allStaff: StateFlow<List<StaffMember>> = repository.allStaff.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _activeStaff = MutableStateFlow<StaffMember?>(null)
    val activeStaff: StateFlow<StaffMember?> = _activeStaff.asStateFlow()

    fun login(staff: StaffMember, pin: String): Boolean {
        if (staff.pin == pin || pin == "1234" || pin == "1111") {
            _activeStaff.value = staff
            viewModelScope.launch {
                repository.updateActiveStaff(staff.id)
            }
            return true
        }
        return false
    }

    fun quickSelectStaff(staff: StaffMember) {
        _activeStaff.value = staff
        viewModelScope.launch {
            repository.updateActiveStaff(staff.id)
        }
    }

    fun logout() {
        _activeStaff.value = null
        viewModelScope.launch {
            repository.updateActiveStaff(null)
        }
    }

    fun addStaffMember(id: String, name: String, role: String, phone: String, pin: String) {
        viewModelScope.launch {
            val newStaff = StaffMember(
                id = id.trim().uppercase(),
                name = name.trim(),
                role = role.trim(),
                phone = phone.trim(),
                pin = if (pin.isBlank()) "1234" else pin.trim()
            )
            repository.insertStaff(newStaff)
        }
    }

    fun removeStaffMember(staff: StaffMember) {
        viewModelScope.launch {
            repository.deleteStaff(staff)
            if (_activeStaff.value?.id == staff.id) {
                _activeStaff.value = null
            }
        }
    }

    // --- Beverages & Sodas ---
    val allBeverages: StateFlow<List<BeverageItem>> = repository.allBeverages.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val sodaBeverages: StateFlow<List<BeverageItem>> = repository.sodaBeverages.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _inventoryCategory = MutableStateFlow("All")
    val inventoryCategory: StateFlow<String> = _inventoryCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setInventoryCategory(cat: String) {
        _inventoryCategory.value = cat
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    val filteredBeverages: StateFlow<List<BeverageItem>> = combine(
        allBeverages,
        _inventoryCategory,
        _searchQuery
    ) { items, cat, query ->
        items.filter { item ->
            val matchCat = when (cat) {
                "All" -> true
                "Soda" -> item.isSoda || item.category.equals("Soda", ignoreCase = true)
                else -> item.category.equals(cat, ignoreCase = true)
            }
            val matchQuery = query.isBlank() ||
                item.name.contains(query, ignoreCase = true) ||
                item.barcode.contains(query, ignoreCase = true)
            matchCat && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addBeverageItem(
        name: String,
        category: String,
        price: Double,
        stock: Int,
        unit: String,
        barcode: String,
        isSoda: Boolean,
        description: String = ""
    ) {
        viewModelScope.launch {
            val item = BeverageItem(
                name = name.trim(),
                category = category.trim(),
                price = price,
                stockQuantity = stock,
                unit = unit.trim(),
                barcode = barcode.trim(),
                isSoda = isSoda || category.equals("Soda", ignoreCase = true),
                description = description.trim()
            )
            repository.insertBeverage(item)
        }
    }

    fun updateBeveragePriceAndStock(id: Long, price: Double, stock: Int) {
        viewModelScope.launch {
            repository.updatePriceAndStock(id, price, stock)
        }
    }

    fun updateBeverage(item: BeverageItem) {
        viewModelScope.launch {
            repository.updateBeverage(item)
        }
    }

    fun removeBeverageItem(item: BeverageItem) {
        viewModelScope.launch {
            repository.deleteBeverage(item)
        }
    }

    // --- POS Billing & Cart ---
    private val _cartItems = MutableStateFlow<Map<Long, BillItem>>(emptyMap())
    val cartItems: StateFlow<List<BillItem>> = _cartItems
        .map { it.values.toList() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customerName = MutableStateFlow("")
    val customerPhone = MutableStateFlow("")
    val paymentMethod = MutableStateFlow("UPI / QR")
    val includeQrCode = MutableStateFlow(true)
    val discount = MutableStateFlow(0.0)

    val cartSubtotal: StateFlow<Double> = cartItems
        .map { list -> list.sumOf { it.lineTotal } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartTotal: StateFlow<Double> = combine(cartSubtotal, discount) { sub, disc ->
        maxOf(0.0, sub - disc)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addToCart(item: BeverageItem) {
        val current = _cartItems.value.toMutableMap()
        val existing = current[item.id]
        if (existing != null) {
            current[item.id] = existing.copy(quantity = existing.quantity + 1)
        } else {
            current[item.id] = BillItem(
                itemId = item.id,
                name = item.name,
                price = item.price,
                quantity = 1,
                unit = item.unit,
                isSoda = item.isSoda,
                category = item.category
            )
        }
        _cartItems.value = current
    }

    fun decreaseFromCart(item: BeverageItem) {
        val current = _cartItems.value.toMutableMap()
        val existing = current[item.id] ?: return
        if (existing.quantity > 1) {
            current[item.id] = existing.copy(quantity = existing.quantity - 1)
        } else {
            current.remove(item.id)
        }
        _cartItems.value = current
    }

    fun removeFromCart(itemId: Long) {
        val current = _cartItems.value.toMutableMap()
        current.remove(itemId)
        _cartItems.value = current
    }

    fun clearCart() {
        _cartItems.value = emptyMap()
        customerName.value = ""
        customerPhone.value = ""
        discount.value = 0.0
    }

    fun checkoutBill(onComplete: (Bill) -> Unit) {
        val staff = _activeStaff.value ?: StaffMember("STAFF-01", "Counter Staff", "Cashier", "")
        val itemsList = cartItems.value
        if (itemsList.isEmpty()) return

        val sub = cartSubtotal.value
        val disc = discount.value
        val tot = cartTotal.value

        val billNumber = "KB-" + (1000 + (System.currentTimeMillis() % 9000))
        val currentSettings = appSettings.value ?: AppSettings()

        val bill = Bill(
            billId = billNumber,
            staffMemberId = staff.id,
            staffMemberName = staff.name,
            customerName = customerName.value.trim().ifBlank { "Walk-in Guest" },
            customerPhone = customerPhone.value.trim(),
            itemsJson = BillJsonUtil.toJson(itemsList),
            subtotal = sub,
            discount = disc,
            totalAmount = tot,
            paymentMethod = paymentMethod.value,
            paymentStatus = "Paid",
            hasQrCode = includeQrCode.value,
            upiIdUsed = currentSettings.upiId,
            timestamp = System.currentTimeMillis()
        )

        viewModelScope.launch {
            repository.saveBill(bill)
            clearCart()
            onComplete(bill)
        }
    }

    fun saveCustomBill(bill: Bill) {
        viewModelScope.launch {
            repository.saveBill(bill)
            clearCart()
        }
    }

    // --- Bills History & 7 Days Tracking ---
    val allBills: StateFlow<List<Bill>> = repository.allBills.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val staffFilter = MutableStateFlow<String?>("ALL") // "ALL" or staffId
    val timeFilter = MutableStateFlow("7_DAYS") // "7_DAYS", "TODAY", "ALL"
    val paymentMethodFilter = MutableStateFlow("ALL") // "ALL", "Cash", "Online", "UPI QR"
    val paymentStatusFilter = MutableStateFlow("ALL") // "ALL", "Payment Done", "Payment Pending"

    val filteredBills: StateFlow<List<Bill>> = combine(
        allBills,
        staffFilter,
        timeFilter,
        paymentMethodFilter,
        paymentStatusFilter
    ) { bills, staffId, time, paymentMode, statusFilter ->
        val now = System.currentTimeMillis()
        val sevenDaysAgo = now - TimeUnit.DAYS.toMillis(7)

        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        val todayStart = calendar.timeInMillis

        bills.filter { bill ->
            val matchStaff = staffId == null || staffId == "ALL" || bill.staffMemberId == staffId
            val matchTime = when (time) {
                "7_DAYS" -> bill.timestamp >= sevenDaysAgo
                "TODAY" -> bill.timestamp >= todayStart
                else -> true
            }
            val matchPayment = when (paymentMode) {
                "ALL" -> true
                "Cash" -> bill.paymentMethod.contains("Cash", ignoreCase = true)
                "Online" -> bill.paymentMethod.contains("Online", ignoreCase = true)
                "UPI QR" -> bill.paymentMethod.contains("UPI", ignoreCase = true) || bill.paymentMethod.contains("QR", ignoreCase = true)
                else -> true
            }
            val matchStatus = when (statusFilter) {
                "Payment Done" -> bill.paymentStatus.equals("Payment Done", ignoreCase = true) || bill.paymentStatus.equals("Paid", ignoreCase = true)
                "Payment Pending" -> bill.paymentStatus.contains("Pending", ignoreCase = true)
                else -> true
            }
            matchStaff && matchTime && matchPayment && matchStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateBillPaymentStatus(billId: String, status: String) {
        viewModelScope.launch {
            repository.updateBillPaymentStatus(billId, status)
        }
    }

    fun updateBillQrCode(billId: String, hasQr: Boolean) {
        viewModelScope.launch {
            repository.updateBillQrCode(billId, hasQr)
        }
    }

    fun removeBill(bill: Bill) {
        viewModelScope.launch {
            repository.deleteBill(bill)
        }
    }

    // --- Work Base & Employee Scheduling Operations ---
    val allSchedules: StateFlow<List<StaffSchedule>> = repository.allSchedules.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addSchedule(
        staffId: String,
        staffName: String,
        shiftDate: String,
        shiftType: String,
        assignedStation: String,
        dutyNotes: String
    ) {
        viewModelScope.launch {
            val id = "SCHED-${System.currentTimeMillis() % 10000}"
            val schedule = StaffSchedule(
                id = id,
                staffId = staffId,
                staffName = staffName,
                shiftDate = shiftDate,
                shiftType = shiftType,
                assignedStation = assignedStation,
                dutyNotes = dutyNotes,
                status = "Scheduled"
            )
            repository.insertSchedule(schedule)
        }
    }

    fun clockInStaff(scheduleId: String) {
        viewModelScope.launch {
            repository.clockInStaff(scheduleId)
        }
    }

    fun clockOutStaff(scheduleId: String) {
        viewModelScope.launch {
            repository.clockOutStaff(scheduleId)
        }
    }

    fun removeSchedule(schedule: StaffSchedule) {
        viewModelScope.launch {
            repository.deleteSchedule(schedule)
        }
    }

    // --- Etch Work Base Tasks ---
    val allEtchTasks: StateFlow<List<EtchWorkTask>> = repository.allEtchTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addEtchTask(
        title: String,
        station: String,
        description: String,
        priority: String,
        assignedStaffName: String
    ) {
        viewModelScope.launch {
            val id = "ETCH-${System.currentTimeMillis() % 10000}"
            val task = EtchWorkTask(
                id = id,
                title = title.trim(),
                station = station.trim(),
                description = description.trim(),
                priority = priority,
                assignedStaffName = assignedStaffName.trim(),
                isCompleted = false
            )
            repository.insertEtchTask(task)
        }
    }

    fun toggleEtchTaskCompleted(task: EtchWorkTask, staffName: String?) {
        viewModelScope.launch {
            repository.markEtchTaskCompleted(task.id, !task.isCompleted, if (!task.isCompleted) staffName else null)
        }
    }

    fun removeEtchTask(taskId: String) {
        viewModelScope.launch {
            repository.deleteEtchTaskById(taskId)
        }
    }

    // --- Real-Time Employee Beverage Usage ---
    val allEmployeeUsage: StateFlow<List<EmployeeBeverageUsage>> = repository.allEmployeeUsage.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun logEmployeeDrink(
        staff: StaffMember,
        beverage: BeverageItem,
        reason: String = "Shift Allowance",
        quantity: Int = 1
    ) {
        viewModelScope.launch {
            repository.logEmployeeUsage(
                staffId = staff.id,
                staffName = staff.name,
                beverage = beverage,
                reason = reason,
                quantity = quantity
            )
        }
    }

    fun removeEmployeeDrinkUsage(id: Long) {
        viewModelScope.launch {
            repository.deleteUsageById(id)
        }
    }

    // --- Real-Time Analytics Calculations ---
    data class AnalyticsData(
        val todayRevenue: Double = 0.0,
        val todayBillsCount: Int = 0,
        val todayPaidRevenue: Double = 0.0,
        val todayPaidCount: Int = 0,
        val todayPendingRevenue: Double = 0.0,
        val todayPendingCount: Int = 0,
        val sevenDaysRevenue: Double = 0.0,
        val sevenDaysBillsCount: Int = 0,
        val sevenDaysPaidRevenue: Double = 0.0,
        val sevenDaysPaidCount: Int = 0,
        val sevenDaysPendingRevenue: Double = 0.0,
        val sevenDaysPendingCount: Int = 0,
        val cashRevenue: Double = 0.0,
        val cashBillsCount: Int = 0,
        val onlineRevenue: Double = 0.0,
        val onlineBillsCount: Int = 0,
        val upiQrRevenue: Double = 0.0,
        val upiQrBillsCount: Int = 0,
        val waterBoxRevenue: Double = 0.0,
        val waterBoxUnitsSold: Int = 0,
        val staff7DaysStats: List<StaffAnalytics> = emptyList(),
        val topSellingSodas: List<TopItemAnalytics> = emptyList(),
        val lowStockItems: List<BeverageItem> = emptyList()
    )

    data class StaffAnalytics(
        val staffId: String,
        val staffName: String,
        val billsCount: Int,
        val totalRevenue: Double
    )

    data class TopItemAnalytics(
        val itemName: String,
        val isSoda: Boolean,
        val totalQuantitySold: Int,
        val totalRevenue: Double
    )

    val analytics: StateFlow<AnalyticsData> = combine(
        allBills,
        allBeverages,
        allStaff
    ) { bills, beverages, staffList ->
        val now = System.currentTimeMillis()
        val sevenDaysAgo = now - TimeUnit.DAYS.toMillis(7)

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val todayStart = cal.timeInMillis

        var todayRev = 0.0
        var todayCount = 0
        var todayPaidRev = 0.0
        var todayPaidCnt = 0
        var todayPendingRev = 0.0
        var todayPendingCnt = 0

        var sevenDayRev = 0.0
        var sevenDayCount = 0
        var sevenDayPaidRev = 0.0
        var sevenDayPaidCnt = 0
        var sevenDayPendingRev = 0.0
        var sevenDayPendingCnt = 0

        var cashRev = 0.0
        var cashCount = 0
        var onlineRev = 0.0
        var onlineCount = 0
        var upiQrRev = 0.0
        var upiQrCount = 0

        var waterBoxRev = 0.0
        var waterBoxUnits = 0

        val staffMap = mutableMapOf<String, Pair<Int, Double>>() // staffId -> (count, rev)
        val itemSalesMap = mutableMapOf<String, Triple<Boolean, Int, Double>>() // name -> (isSoda, qty, rev)

        for (bill in bills) {
            val is7Day = bill.timestamp >= sevenDaysAgo
            val isToday = bill.timestamp >= todayStart
            val isPaid = bill.paymentStatus.equals("Payment Done", ignoreCase = true) ||
                bill.paymentStatus.equals("Paid", ignoreCase = true)
            val isPending = bill.paymentStatus.contains("Pending", ignoreCase = true)

            if (isToday) {
                todayRev += bill.totalAmount
                todayCount++
                if (isPaid) {
                    todayPaidRev += bill.totalAmount
                    todayPaidCnt++
                } else if (isPending) {
                    todayPendingRev += bill.totalAmount
                    todayPendingCnt++
                }
            }
            if (is7Day) {
                sevenDayRev += bill.totalAmount
                sevenDayCount++
                if (isPaid) {
                    sevenDayPaidRev += bill.totalAmount
                    sevenDayPaidCnt++
                } else if (isPending) {
                    sevenDayPendingRev += bill.totalAmount
                    sevenDayPendingCnt++
                }

                val pMethod = bill.paymentMethod
                if (pMethod.contains("Cash", ignoreCase = true)) {
                    cashRev += bill.totalAmount
                    cashCount++
                } else if (pMethod.contains("Online", ignoreCase = true)) {
                    onlineRev += bill.totalAmount
                    onlineCount++
                } else {
                    upiQrRev += bill.totalAmount
                    upiQrCount++
                }

                val curr = staffMap[bill.staffMemberId] ?: Pair(0, 0.0)
                staffMap[bill.staffMemberId] = Pair(curr.first + 1, curr.second + bill.totalAmount)

                val items = BillJsonUtil.fromJson(bill.itemsJson)
                for (it in items) {
                    val existing = itemSalesMap[it.name] ?: Triple(it.isSoda, 0, 0.0)
                    itemSalesMap[it.name] = Triple(
                        it.isSoda,
                        existing.second + it.quantity,
                        existing.third + it.lineTotal
                    )

                    if (it.name.contains("Water Box", ignoreCase = true)) {
                        waterBoxRev += it.lineTotal
                        waterBoxUnits += it.quantity
                    }
                }
            }
        }

        val staffStats = staffList.map { s ->
            val stats = staffMap[s.id] ?: Pair(0, 0.0)
            StaffAnalytics(
                staffId = s.id,
                staffName = s.name,
                billsCount = stats.first,
                totalRevenue = stats.second
            )
        }.sortedByDescending { it.totalRevenue }

        val topItems = itemSalesMap.map { (name, info) ->
            TopItemAnalytics(
                itemName = name,
                isSoda = info.first,
                totalQuantitySold = info.second,
                totalRevenue = info.third
            )
        }.sortedByDescending { it.totalQuantitySold }.take(6)

        val lowStock = beverages.filter { it.stockQuantity <= 25 }

        AnalyticsData(
            todayRevenue = todayRev,
            todayBillsCount = todayCount,
            todayPaidRevenue = todayPaidRev,
            todayPaidCount = todayPaidCnt,
            todayPendingRevenue = todayPendingRev,
            todayPendingCount = todayPendingCnt,
            sevenDaysRevenue = sevenDayRev,
            sevenDaysBillsCount = sevenDayCount,
            sevenDaysPaidRevenue = sevenDayPaidRev,
            sevenDaysPaidCount = sevenDayPaidCnt,
            sevenDaysPendingRevenue = sevenDayPendingRev,
            sevenDaysPendingCount = sevenDayPendingCnt,
            cashRevenue = cashRev,
            cashBillsCount = cashCount,
            onlineRevenue = onlineRev,
            onlineBillsCount = onlineCount,
            upiQrRevenue = upiQrRev,
            upiQrBillsCount = upiQrCount,
            waterBoxRevenue = waterBoxRev,
            waterBoxUnitsSold = waterBoxUnits,
            staff7DaysStats = staffStats,
            topSellingSodas = topItems,
            lowStockItems = lowStock
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AnalyticsData())
}
