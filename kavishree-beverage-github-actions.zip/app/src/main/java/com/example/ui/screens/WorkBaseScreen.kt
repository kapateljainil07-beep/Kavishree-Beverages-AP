package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.EmojiFoodBeverage
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BeverageItem
import com.example.data.model.EmployeeBeverageUsage
import com.example.data.model.EtchWorkTask
import com.example.data.model.StaffMember
import com.example.data.model.StaffSchedule
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkBaseScreen(
    schedules: List<StaffSchedule>,
    etchTasks: List<EtchWorkTask>,
    employeeUsage: List<EmployeeBeverageUsage>,
    staffList: List<StaffMember>,
    beverages: List<BeverageItem>,
    activeStaff: StaffMember?,
    isAuthorityUnlocked: Boolean,
    isOnline: Boolean,
    cloudSyncStatus: String,
    onVerifyAuthorityPin: (String) -> Boolean,
    onLockAuthority: () -> Unit,
    onToggleOnlineMode: () -> Unit,
    onSyncNow: () -> Unit,
    onAddSchedule: (staffId: String, staffName: String, shiftDate: String, shiftType: String, station: String, notes: String) -> Unit,
    onClockIn: (String) -> Unit,
    onClockOut: (String) -> Unit,
    onDeleteSchedule: (StaffSchedule) -> Unit,
    onAddEtchTask: (title: String, station: String, description: String, priority: String, assignedStaff: String) -> Unit,
    onToggleEtchCompleted: (EtchWorkTask, String?) -> Unit,
    onDeleteEtchTask: (String) -> Unit,
    onLogEmployeeDrink: (staff: StaffMember, beverage: BeverageItem, reason: String, quantity: Int) -> Unit,
    onDeleteUsage: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableIntStateOf(0) }
    val sectionTitles = listOf("App Scheduling", "Etch Work Base", "Employee Usage")

    var showAuthorityDialog by remember { mutableStateOf(false) }
    var showAddScheduleDialog by remember { mutableStateOf(false) }
    var showAddEtchDialog by remember { mutableStateOf(false) }
    var showLogDrinkDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // One Access Master Authority & Cloud Sync Control Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isAuthorityUnlocked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("one_access_authority_card")
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isAuthorityUnlocked) Icons.Default.LockOpen else Icons.Default.Security,
                            contentDescription = "Authority Shield",
                            tint = if (isAuthorityUnlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "One Access Operate Authorities",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = if (isAuthorityUnlocked) "Master Control Unlocked • Full Scheduling & Etch Base Access" else "Operate Authority Protected • PIN Required",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    color = if (isAuthorityUnlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    // Authority Unlock / Lock Button
                    Button(
                        onClick = {
                            if (isAuthorityUnlocked) {
                                onLockAuthority()
                            } else {
                                showAuthorityDialog = true
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAuthorityUnlocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("operate_authorities_toggle_button")
                    ) {
                        Text(
                            text = if (isAuthorityUnlocked) "Lock Authority" else "Operate Authority",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))

                // Cloud Online Sync & Cross-Platform (Android + iOS) row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                if (isAuthorityUnlocked) {
                                    onToggleOnlineMode()
                                } else {
                                    showAuthorityDialog = true
                                }
                            }
                            .padding(2.dp)
                    ) {
                        Icon(
                            imageVector = if (isOnline) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = "Cloud Status",
                            tint = if (isOnline) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = if (isOnline) "Cloud DB: Online" else "Cloud DB: Offline",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isOnline) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Text(
                                text = cloudSyncStatus,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Quick sync trigger
                        IconButton(
                            onClick = onSyncNow,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Sync Cloud",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Android & iOS Universal Support Badge
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Devices,
                                    contentDescription = "Cross-Platform",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Android & iOS Ready",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Navigation Tabs for Scheduling, Etch Work Base, Employee Usage
        TabRow(
            selectedTabIndex = selectedSection,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            sectionTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSection == index,
                    onClick = { selectedSection = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (selectedSection == index) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tab Content
        when (selectedSection) {
            0 -> SchedulingSection(
                schedules = schedules,
                isAuthorityUnlocked = isAuthorityUnlocked,
                onAddNewScheduleClick = {
                    if (isAuthorityUnlocked) {
                        showAddScheduleDialog = true
                    } else {
                        showAuthorityDialog = true
                    }
                },
                onClockIn = onClockIn,
                onClockOut = onClockOut,
                onDeleteSchedule = onDeleteSchedule
            )
            1 -> EtchWorkBaseSection(
                tasks = etchTasks,
                activeStaff = activeStaff,
                isAuthorityUnlocked = isAuthorityUnlocked,
                onAddNewTaskClick = {
                    if (isAuthorityUnlocked) {
                        showAddEtchDialog = true
                    } else {
                        showAuthorityDialog = true
                    }
                },
                onToggleCompleted = onToggleEtchCompleted,
                onDeleteTask = onDeleteEtchTask
            )
            2 -> EmployeeUsageSection(
                usages = employeeUsage,
                isAuthorityUnlocked = isAuthorityUnlocked,
                onLogDrinkClick = {
                    showLogDrinkDialog = true
                },
                onDeleteUsage = onDeleteUsage
            )
        }
    }

    // Master Authority PIN Dialog
    if (showAuthorityDialog) {
        var inputPin by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAuthorityDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Operate Authorities Access", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        text = "Enter Master Authority PIN to unlock App Scheduling, Etch Work Base assignments, and Cloud Online sync settings (Default: 9999).",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inputPin,
                        onValueChange = {
                            inputPin = it
                            pinError = false
                        },
                        label = { Text("Authority PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        isError = pinError,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("authority_pin_input")
                    )
                    if (pinError) {
                        Text(
                            text = "Incorrect Authority PIN. Please try again (e.g. 9999).",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val verified = onVerifyAuthorityPin(inputPin)
                        if (verified) {
                            showAuthorityDialog = false
                        } else {
                            pinError = true
                        }
                    },
                    modifier = Modifier.testTag("submit_authority_pin_button")
                ) {
                    Text("Unlock Authorities")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAuthorityDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Staff Schedule Dialog
    if (showAddScheduleDialog) {
        AddScheduleDialog(
            staffList = staffList,
            onDismiss = { showAddScheduleDialog = false },
            onConfirm = { staffId, staffName, shiftDate, shiftType, station, notes ->
                onAddSchedule(staffId, staffName, shiftDate, shiftType, station, notes)
                showAddScheduleDialog = false
            }
        )
    }

    // Add Etch Task Dialog
    if (showAddEtchDialog) {
        AddEtchTaskDialog(
            staffList = staffList,
            onDismiss = { showAddEtchDialog = false },
            onConfirm = { title, station, description, priority, assignedStaff ->
                onAddEtchTask(title, station, description, priority, assignedStaff)
                showAddEtchDialog = false
            }
        )
    }

    // Log Employee Beverage Drink Dialog
    if (showLogDrinkDialog) {
        LogEmployeeDrinkDialog(
            staffList = staffList,
            beverages = beverages,
            onDismiss = { showLogDrinkDialog = false },
            onConfirm = { staff, beverage, reason, quantity ->
                onLogEmployeeDrink(staff, beverage, reason, quantity)
                showLogDrinkDialog = false
            }
        )
    }
}

// -------------------------------------------------------------
// Sub-Section 1: App Scheduling (Rosters, Shifts, Working Hours)
// -------------------------------------------------------------
@Composable
private fun SchedulingSection(
    schedules: List<StaffSchedule>,
    isAuthorityUnlocked: Boolean,
    onAddNewScheduleClick: () -> Unit,
    onClockIn: (String) -> Unit,
    onClockOut: (String) -> Unit,
    onDeleteSchedule: (StaffSchedule) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "Weekly Staff Roster & Shifts",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "7-Day scheduling for beverage production & billing staff",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onAddNewScheduleClick,
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("add_schedule_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Shift", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (schedules.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No schedules created yet.\nTap 'Add Shift' to assign weekly staff rosters.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(schedules, key = { it.id }) { item ->
                    val statusColor = when (item.status) {
                        "On-Duty" -> Color(0xFF2E7D32)
                        "Completed" -> Color(0xFF1565C0)
                        else -> Color(0xFFE65100)
                    }

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Schedule,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = item.staffName,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${item.shiftDate} • ${item.shiftType}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.primary,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = statusColor.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = item.status,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Station: ${item.assignedStation}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )

                            if (item.dutyNotes.isNotBlank()) {
                                Text(
                                    text = "Notes: ${item.dutyNotes}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (item.status != "On-Duty" && item.status != "Completed") {
                                        Button(
                                            onClick = { onClockIn(item.id) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Clock In", fontSize = 11.sp)
                                        }
                                    } else if (item.status == "On-Duty") {
                                        Button(
                                            onClick = { onClockOut(item.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Clock Out", fontSize = 11.sp)
                                        }
                                    }
                                }

                                if (isAuthorityUnlocked) {
                                    IconButton(
                                        onClick = { onDeleteSchedule(item) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-Section 2: Etch Work Base (Bottling, Etching, Maintenance)
// -------------------------------------------------------------
@Composable
private fun EtchWorkBaseSection(
    tasks: List<EtchWorkTask>,
    activeStaff: StaffMember?,
    isAuthorityUnlocked: Boolean,
    onAddNewTaskClick: () -> Unit,
    onToggleCompleted: (EtchWorkTask, String?) -> Unit,
    onDeleteTask: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "Etch Work Base & Production",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Laser bottle etching, machinery maintenance & batch checks",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onAddNewTaskClick,
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("add_etch_task_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Task", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (tasks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No Etch Work Base tasks found.\nAdd batch etching or equipment maintenance tasks.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(tasks, key = { it.id }) { task ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (task.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Handyman,
                                        contentDescription = null,
                                        tint = if (task.isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = task.title,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (task.isCompleted) Color(0xFF2E7D32).copy(alpha = 0.15f) else Color(0xFFE65100).copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (task.isCompleted) "Completed" else "Pending",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (task.isCompleted) Color(0xFF2E7D32) else Color(0xFFE65100),
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Station: ${task.station}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
                            )
                            if (task.description.isNotBlank()) {
                                Text(
                                    text = task.description,
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Assigned: ${task.assignedStaffName} • Priority: ${task.priority}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    TextButton(
                                        onClick = {
                                            onToggleCompleted(task, activeStaff?.name ?: "Staff")
                                        },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (task.isCompleted) Icons.Default.Refresh else Icons.Default.Check,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (task.isCompleted) "Reopen" else "Complete",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    if (isAuthorityUnlocked) {
                                        IconButton(
                                            onClick = { onDeleteTask(task.id) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --------------------------------------------------------------------------
// Sub-Section 3: Real-Time Beverage Employee Usage (Employee Drink Logging)
// --------------------------------------------------------------------------
@Composable
private fun EmployeeUsageSection(
    usages: List<EmployeeBeverageUsage>,
    isAuthorityUnlocked: Boolean,
    onLogDrinkClick: () -> Unit,
    onDeleteUsage: (Long) -> Unit
) {
    val totalDrinksLogged = usages.sumOf { it.quantity }

    Column(modifier = Modifier.fillMaxSize()) {
        // Summary Metrics Bar
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Real-Time Beverage Employ Usage",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Total Drinks Consumed: $totalDrinksLogged • Real-time shift tracking",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSecondaryContainer)
                    )
                }

                Button(
                    onClick = onLogDrinkClick,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("log_employee_drink_button")
                ) {
                    Icon(imageVector = Icons.Default.EmojiFoodBeverage, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Drink", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (usages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No employee beverage usage logged today.\nTap 'Log Drink' to record staff refreshment consumption.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(usages, key = { it.id }) { log ->
                    val dateFormatted = SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault()).format(Date(log.timestamp))

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "🥤",
                                        fontSize = 18.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${log.staffName} • ${log.beverageName} (${log.quantity}x)",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Reason: ${log.reason} • $dateFormatted",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }

                            if (isAuthorityUnlocked) {
                                IconButton(
                                    onClick = { onDeleteUsage(log.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Dialog: Add Staff Schedule
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddScheduleDialog(
    staffList: List<StaffMember>,
    onDismiss: () -> Unit,
    onConfirm: (staffId: String, staffName: String, shiftDate: String, shiftType: String, station: String, notes: String) -> Unit
) {
    var selectedStaff by remember { mutableStateOf(staffList.firstOrNull()) }
    var shiftDate by remember { mutableStateOf("Today") }
    var shiftType by remember { mutableStateOf("Morning (08:00 - 14:00)") }
    var assignedStation by remember { mutableStateOf("Station 1: Soda & Etch Dispenser") }
    var notes by remember { mutableStateOf("") }

    val shiftTypes = listOf("Morning (08:00 - 14:00)", "Evening (14:00 - 20:00)", "Night (20:00 - 23:30)", "Full Day")
    val stations = listOf(
        "Station 1: Soda & Etch Dispenser",
        "Station 2: Water Box & Dispatch",
        "Station 3: POS Billing Desk",
        "Station 4: Juices & Drinks"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add App Schedule Shift", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Select Staff Member:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(staffList) { s ->
                        FilterChip(
                            selected = selectedStaff?.id == s.id,
                            onClick = { selectedStaff = s },
                            label = { Text(s.name.split(" ").firstOrNull() ?: s.id, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = shiftDate,
                    onValueChange = { shiftDate = it },
                    label = { Text("Shift Date / Day") },
                    placeholder = { Text("e.g. Today or Monday") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Shift Duration:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(shiftTypes) { st ->
                        FilterChip(
                            selected = shiftType == st,
                            onClick = { shiftType = st },
                            label = { Text(st.split(" ").firstOrNull() ?: st, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("Assigned Station:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                stations.forEach { st ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { assignedStation = st }
                            .padding(vertical = 2.dp)
                    ) {
                        FilterChip(
                            selected = assignedStation == st,
                            onClick = { assignedStation = st },
                            label = { Text(st, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Duty Notes (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val staff = selectedStaff ?: staffList.firstOrNull()
                    if (staff != null) {
                        onConfirm(
                            staff.id,
                            staff.name,
                            shiftDate.trim(),
                            shiftType,
                            assignedStation,
                            notes.trim()
                        )
                    }
                }
            ) {
                Text("Save Shift")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// -------------------------------------------------------------
// Dialog: Add Etch Work Base Task
// -------------------------------------------------------------
@Composable
private fun AddEtchTaskDialog(
    staffList: List<StaffMember>,
    onDismiss: () -> Unit,
    onConfirm: (title: String, station: String, description: String, priority: String, assignedStaff: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var station by remember { mutableStateOf("Station 1: Soda & Etch Dispenser") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("High") }
    var assignedStaffName by remember { mutableStateOf(staffList.firstOrNull()?.name ?: "Duty Staff") }

    val stations = listOf(
        "Station 1: Soda & Etch Dispenser",
        "Station 2: Water Box & Dispatch",
        "Station 3: Drink Processing"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Etch Work Base Task", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title") },
                    placeholder = { Text("e.g. Laser Etch Bottle Batch #502") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Station / Work Base:", style = MaterialTheme.typography.labelMedium)
                stations.forEach { st ->
                    FilterChip(
                        selected = station == st,
                        onClick = { station = st },
                        label = { Text(st, fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Task Specs / Instructions") },
                    placeholder = { Text("e.g. 500 units Lemon Soda 300ml bottle etch") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Priority Level:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("High", "Normal", "Routine").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title.trim(), station, description.trim(), priority, assignedStaffName)
                    }
                }
            ) {
                Text("Create Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// -------------------------------------------------------------
// Dialog: Log Employee Beverage Drink
// -------------------------------------------------------------
@Composable
private fun LogEmployeeDrinkDialog(
    staffList: List<StaffMember>,
    beverages: List<BeverageItem>,
    onDismiss: () -> Unit,
    onConfirm: (staff: StaffMember, beverage: BeverageItem, reason: String, quantity: Int) -> Unit
) {
    var selectedStaff by remember { mutableStateOf(staffList.firstOrNull()) }
    var selectedBeverage by remember { mutableStateOf(beverages.firstOrNull()) }
    var quantityText by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("Shift Allowance") }

    val reasons = listOf("Shift Allowance", "Tasting & Quality", "Duty Break")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Employee Beverage Drink", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Select Employee:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(staffList) { s ->
                        FilterChip(
                            selected = selectedStaff?.id == s.id,
                            onClick = { selectedStaff = s },
                            label = { Text(s.name.split(" ").firstOrNull() ?: s.id, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("Select Beverage / Soda:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(beverages.take(8)) { b ->
                        FilterChip(
                            selected = selectedBeverage?.id == b.id,
                            onClick = { selectedBeverage = b },
                            label = { Text(b.name.take(12), fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("Quantity") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Reason for Consumption:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    reasons.forEach { r ->
                        FilterChip(
                            selected = reason == r,
                            onClick = { reason = r },
                            label = { Text(r, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val staff = selectedStaff ?: staffList.firstOrNull()
                    val bev = selectedBeverage ?: beverages.firstOrNull()
                    val qty = quantityText.toIntOrNull() ?: 1
                    if (staff != null && bev != null) {
                        onConfirm(staff, bev, reason, qty)
                    }
                }
            ) {
                Text("Log Drink")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
