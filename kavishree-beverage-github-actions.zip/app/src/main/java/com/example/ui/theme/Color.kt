package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kavishree Beverage Fresh Mint, Citrus Lime, and Sparkling Soda Palette
val MintTealPrimary = Color(0xFF00796B)
val MintTealPrimaryLight = Color(0xFF48A999)
val MintTealPrimaryDark = Color(0xFF004C40)

val CitrusLimeSecondary = Color(0xFF689F38)
val CitrusLimeLight = Color(0xFF99D066)
val CitrusLimeDark = Color(0xFF387002)

val FizzyAmberTertiary = Color(0xFFE65100)
val FizzyAmberLight = Color(0xFFFF833A)

// Light Theme Neutrals
val LightBackground = Color(0xFFF7FCFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8F5E9)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF191C1C)
val LightOutline = Color(0xFFB2DFDB)

// Dark Theme Neutrals
val DarkBackground = Color(0xFF0E1717)
val DarkSurface = Color(0xFF162222)
val DarkSurfaceVariant = Color(0xFF1E2F2F)
val DarkPrimary = Color(0xFF80CBC4)
val DarkSecondary = Color(0xFFAED581)
val DarkOnSurface = Color(0xFFE0E3E3)
val DarkOutline = Color(0xFF37474F)

// Accents
val SuccessGreen = Color(0xFF2E7D32)
val WarningOrange = Color(0xFFED6C02)
val ErrorRed = Color(0xFFD32F2F)
val WhatsAppGreen = Color(0xFF25D366)
val UpiBlue = Color(0xFF1976D2)

