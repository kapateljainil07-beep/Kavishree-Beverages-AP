package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.util.QrCodeGenerator

@Composable
fun QrCodeView(
    data: String,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp,
    moduleColor: Color = Color.Black,
    backgroundColor: Color = Color.White
) {
    val qrMatrix = remember(data) {
        try {
            QrCodeGenerator.encode(data)
        } catch (e: Exception) {
            null
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        if (qrMatrix != null) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val moduleCount = qrMatrix.size
                val cellSize = minOf(this.size.width, this.size.height) / moduleCount

                for (r in 0 until moduleCount) {
                    for (c in 0 until moduleCount) {
                        if (qrMatrix[r, c]) {
                            drawRect(
                                color = moduleColor,
                                topLeft = Offset(c * cellSize, r * cellSize),
                                size = Size(cellSize, cellSize)
                            )
                        }
                    }
                }
            }
        }
    }
}
