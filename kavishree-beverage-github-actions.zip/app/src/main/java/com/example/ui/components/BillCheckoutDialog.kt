package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppSettings
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.StaffMember
import com.example.data.util.BillJsonUtil
import com.example.data.util.WhatsAppUtil
import com.example.ui.theme.UpiBlue
import com.example.ui.theme.WhatsAppGreen
import java.net.URLEncoder
import java.util.Locale

@Composable
fun BillCheckoutDialog(
    cartItems: List<BillItem>,
    subtotal: Double,
    activeStaff: StaffMember?,
    appSettings: AppSettings?,
    onSaveBill: (Bill) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("UPI QR") } // "Cash", "Online", "UPI QR"
    var paymentStatus by remember { mutableStateOf("Payment Done") } // "Payment Done", "Payment Pending"
    var cashReceivedText by remember { mutableStateOf("") }
    var onlineSubMethod by remember { mutableStateOf("Card / POS Swiper") }
    var onlineRefText by remember { mutableStateOf("") }
    var includeQrCode by remember {
        mutableStateOf(appSettings?.enableQrOnBill ?: true)
    }
    var discountText by remember { mutableStateOf("") }

    val discount = discountText.toDoubleOrNull() ?: 0.0
    val total = maxOf(0.0, subtotal - discount)
    val upiId = appSettings?.upiId ?: "kavishreebeverage@upi"
    val storeName = appSettings?.payeeName ?: "Kavishree Beverage"
    val storeAddress = appSettings?.storeAddress ?: "Main Market Hub"

    val cashReceived = cashReceivedText.toDoubleOrNull() ?: total
    val cashChange = maxOf(0.0, cashReceived - total)

    val billNotes = remember(paymentMethod, cashReceived, cashChange, onlineSubMethod, onlineRefText) {
        when (paymentMethod) {
            "Cash" -> if (cashReceived > total) "Cash Recd: ₹${String.format(Locale.US, "%.2f", cashReceived)} | Change: ₹${String.format(Locale.US, "%.2f", cashChange)}" else "Cash Paid Exactly"
            "Online" -> "$onlineSubMethod${if (onlineRefText.isNotBlank()) " [Ref: ${onlineRefText.trim()}]" else ""}"
            else -> "UPI QR: $upiId"
        }
    }

    // Construct preview bill object for WhatsApp / QR
    val tempBill = remember(customerName, customerPhone, total, paymentMethod, paymentStatus, includeQrCode, billNotes) {
        Bill(
            billId = "KB-" + (1000 + (System.currentTimeMillis() % 9000)),
            staffMemberId = activeStaff?.id ?: "STAFF-01",
            staffMemberName = activeStaff?.name ?: "Counter Staff",
            customerName = customerName.trim().ifBlank { "Valued Customer" },
            customerPhone = customerPhone.trim(),
            itemsJson = BillJsonUtil.toJson(cartItems),
            subtotal = subtotal,
            discount = discount,
            totalAmount = total,
            paymentMethod = paymentMethod,
            paymentStatus = paymentStatus,
            hasQrCode = if (paymentMethod == "UPI QR") includeQrCode else false,
            upiIdUsed = upiId,
            notes = billNotes,
            timestamp = System.currentTimeMillis()
        )
    }

    val upiPaymentUri = remember(upiId, total, storeName) {
        "upi://pay?pa=$upiId&pn=${URLEncoder.encode(storeName, "UTF-8")}&am=${String.format(Locale.US, "%.2f", total)}&cu=INR&tn=Bill%20${tempBill.billId}"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Complete Bill & Payment",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Staff: ${activeStaff?.name ?: "Staff"} (${activeStaff?.id ?: "STAFF-01"})",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Customer details card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Customer Details for WhatsApp Receipt",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Customer Name") },
                            placeholder = { Text("e.g. Rahul Patel") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("customer_name_input")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = customerPhone,
                            onValueChange = { customerPhone = it },
                            label = { Text("Customer WhatsApp Number") },
                            placeholder = { Text("10-digit phone number") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = WhatsAppGreen
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("customer_phone_input")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Item breakdown summary
                Text(
                    text = "Items (${cartItems.sumOf { it.quantity }} items)",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(6.dp))

                cartItems.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${if (item.isSoda) "🥤" else "🍹"} ${item.name} × ${item.quantity}",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "₹${String.format(Locale.US, "%.2f", item.lineTotal)}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))

                // Subtotal, discount & Grand total
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
                    Text("₹${String.format(Locale.US, "%.2f", subtotal)}", style = MaterialTheme.typography.bodyMedium)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Discount (₹):", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { discountText = it },
                        placeholder = { Text("0") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .width(90.dp)
                            .height(50.dp)
                            .testTag("discount_input")
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    if (discount > 0) {
                        Text(
                            text = "-₹${String.format(Locale.US, "%.2f", discount)}",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Total Payable Amount:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "₹${String.format(Locale.US, "%.2f", total)}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Three Payment Methods: Cash, Online, UPI QR with Purchase Amount
                Text(
                    text = "Payment Method",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val paymentOptions = listOf(
                        Triple("Cash", "💵 Cash", Color(0xFF2E7D32)),
                        Triple("Online", "🌐 Online", Color(0xFF1565C0)),
                        Triple("UPI QR", "📱 UPI QR", Color(0xFF6A1B9A))
                    )
                    paymentOptions.forEach { (mode, label, color) ->
                        val isSelected = paymentMethod == mode
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, color) else null,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .testTag("payment_mode_$mode")
                        ) {
                            TextButton(onClick = { paymentMethod = mode }) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                        color = if (isSelected) color else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Payment Status: Payment Done vs Payment Pending
                Text(
                    text = "Payment Status (Daily Bill Mark)",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isDone = paymentStatus == "Payment Done"
                    val isPending = paymentStatus == "Payment Pending"

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDone) Color(0xFF2E7D32).copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isDone) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF2E7D32)) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { paymentStatus = "Payment Done" }
                            .testTag("status_payment_done")
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (isDone) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Payment Done",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isDone) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isDone) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isPending) Color(0xFFE65100).copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isPending) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFE65100)) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { paymentStatus = "Payment Pending" }
                            .testTag("status_payment_pending")
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = if (isPending) Color(0xFFE65100) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Payment Pending",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isPending) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isPending) Color(0xFFE65100) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Detail card specific to selected payment mode (with Purchase Amount)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 1. CASH PAYMENT OPTION
                        if (paymentMethod == "Cash") {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "💵 Cash Payment",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2E7D32)
                                    )
                                )
                                Text(
                                    text = "Purchase Amount: ₹${String.format(Locale.US, "%.2f", total)}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = cashReceivedText,
                                onValueChange = { cashReceivedText = it },
                                label = { Text("Cash Received from Customer (₹)") },
                                placeholder = { Text(String.format(Locale.US, "%.2f", total)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("cash_received_input")
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Quick cash note buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    "Exact" to total,
                                    "+₹50" to (total + 50.0),
                                    "+₹100" to (total + 100.0),
                                    "+₹500" to (total + 500.0)
                                ).forEach { (lbl, amt) ->
                                    OutlinedButton(
                                        onClick = {
                                            cashReceivedText = if (lbl == "Exact") String.format(Locale.US, "%.2f", total) else String.format(Locale.US, "%.2f", amt)
                                        },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(lbl, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp))
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Change calculation display
                            if (cashReceived > total) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFE8F5E9),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Change to Return:",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1B5E20)
                                            )
                                        )
                                        Text(
                                            text = "₹${String.format(Locale.US, "%.2f", cashChange)}",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color(0xFF1B5E20)
                                            )
                                        )
                                    }
                                }
                            } else if (cashReceived == total) {
                                Text(
                                    text = "✓ Exact Cash Received (₹${String.format(Locale.US, "%.2f", total)})",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }

                        // 2. ONLINE PAYMENT OPTION
                        if (paymentMethod == "Online") {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "🌐 Online Payment",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1565C0)
                                    )
                                )
                                Text(
                                    text = "Purchase Amount: ₹${String.format(Locale.US, "%.2f", total)}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Online sub-method choices
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("Card / POS Swiper", "Net Banking", "Online Gateway").forEach { sub ->
                                    val isSubSelected = onlineSubMethod == sub
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isSubSelected) Color(0xFF1565C0).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
                                        border = if (isSubSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1565C0)) else null,
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(6.dp))
                                    ) {
                                        TextButton(
                                            onClick = { onlineSubMethod = sub },
                                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = sub,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontSize = 9.5.sp,
                                                    fontWeight = if (isSubSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSubSelected) Color(0xFF1565C0) else MaterialTheme.colorScheme.onSurface
                                                ),
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = onlineRefText,
                                onValueChange = { onlineRefText = it },
                                label = { Text("Transaction / Approval Ref No. (Optional)") },
                                placeholder = { Text("e.g. TXN-98421 or Card Auth #") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("online_ref_input")
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "✓ Online terminal ready for Purchase Amount ₹${String.format(Locale.US, "%.2f", total)}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFF1565C0),
                                    fontSize = 11.sp
                                )
                            )
                        }

                        // 3. UPI QR PAYMENT OPTION
                        if (paymentMethod == "UPI QR") {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode,
                                    contentDescription = null,
                                    tint = UpiBlue
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "UPI QR Code Payment",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Purchase Amount: ₹${String.format(Locale.US, "%.2f", total)}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                }
                                Switch(
                                    checked = includeQrCode,
                                    onCheckedChange = { includeQrCode = it },
                                    modifier = Modifier.testTag("toggle_upi_qr_switch"),
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = MaterialTheme.colorScheme.primary,
                                        checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Explicit Add / Remove QR Code buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { includeQrCode = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (includeQrCode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (includeQrCode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("add_qr_code_btn")
                                ) {
                                    Text("➕ Add QR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { includeQrCode = false },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (!includeQrCode) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (!includeQrCode) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("remove_qr_code_btn")
                                ) {
                                    Text("✖ Remove QR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (!includeQrCode) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "QR Code is Removed from this bill. Tap '+ Add QR' if customer wants to scan.",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            fontSize = 11.sp
                                        ),
                                        modifier = Modifier.padding(8.dp),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            if (includeQrCode) {
                                Spacer(modifier = Modifier.height(10.dp))
                                // Dynamic UPI QR Code generated with pure Kotlin Canvas rendering
                                QrCodeView(
                                    data = upiPaymentUri,
                                    size = 150.dp,
                                    modifier = Modifier.testTag("upi_qr_preview")
                                )

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Scan with Google Pay, PhonePe, Paytm, BHIM",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp
                                    )
                                )
                                Text(
                                    text = "UPI ID: $upiId",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )

                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(upiPaymentUri))
                                                context.startActivity(Intent.createChooser(intent, "Pay via UPI App"))
                                            } catch (e: Exception) {
                                                // UPI app not present
                                            }
                                        },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("launch_upi_app_button")
                                    ) {
                                        Text("Open UPI App", fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                            val clip = android.content.ClipData.newPlainText("UPI Pay Link", upiPaymentUri)
                                            clipboard?.setPrimaryClip(clip)
                                            android.widget.Toast.makeText(context, "UPI Payment Link Copied", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Copy Pay Link", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // WhatsApp Bill Send Button ("Coustomer Number To whats App Thru Bill Send it Feature Add")
                Button(
                    onClick = {
                        WhatsAppUtil.sendBillViaWhatsApp(
                            context = context,
                            bill = tempBill,
                            storeName = storeName,
                            storeAddress = storeAddress
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("send_whatsapp_bill_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WhatsAppGreen
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send WhatsApp",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (customerPhone.isNotBlank()) "Send Bill to WhatsApp (${customerPhone})" else "Send Bill to WhatsApp",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSaveBill(tempBill)
                },
                modifier = Modifier.testTag("save_and_complete_bill_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save Bill & Finish")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
