package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.StaffMember
import com.example.ui.components.KavishreeTopBar
import com.example.ui.components.SettingsDialog
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.BillingPosScreen
import com.example.ui.screens.BillsHistoryScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.StaffLoginScreen
import com.example.ui.screens.StaffScreen
import com.example.ui.screens.WorkBaseScreen
import com.example.ui.theme.KavishreeBeverageTheme
import com.example.ui.viewmodel.KavishreeViewModel

enum class MainTab(val title: String, val testTag: String) {
    BILLING("Billing", "tab_billing"),
    BILLS_HISTORY("Bills History", "tab_bills_history"),
    INVENTORY("Inventory", "tab_inventory"),
    WORK_BASE("Work Base", "tab_work_base"),
    STAFF("Staff", "tab_staff"),
    ANALYTICS("Analytics", "tab_analytics")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KavishreeViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            KavishreeBeverageTheme(darkTheme = isDarkMode) {
                KavishreeApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun KavishreeApp(viewModel: KavishreeViewModel) {
    val activeStaff by viewModel.activeStaff.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val allStaff by viewModel.allStaff.collectAsState()
    val appSettings by viewModel.appSettings.collectAsState()

    var currentTab by remember { mutableStateOf(MainTab.BILLING) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showStaffSwitchDialog by remember { mutableStateOf(false) }

    // If no staff member is logged in, show the Staff Login Screen first!
    if (activeStaff == null) {
        StaffLoginScreen(
            staffList = allStaff,
            isDarkMode = isDarkMode,
            onToggleDarkMode = { viewModel.toggleDarkMode() },
            onLoginSuccess = { staff ->
                viewModel.quickSelectStaff(staff)
            }
        )
    } else {
        // Collect state for screens
        val allBeverages by viewModel.allBeverages.collectAsState()
        val filteredBeverages by viewModel.filteredBeverages.collectAsState()
        val cartItems by viewModel.cartItems.collectAsState()
        val cartSubtotal by viewModel.cartSubtotal.collectAsState()
        val selectedCategory by viewModel.inventoryCategory.collectAsState()
        val searchQuery by viewModel.searchQuery.collectAsState()
        val filteredBills by viewModel.filteredBills.collectAsState()
        val selectedStaffFilter by viewModel.staffFilter.collectAsState()
        val selectedTimeRange by viewModel.timeFilter.collectAsState()
        val selectedPaymentStatus by viewModel.paymentStatusFilter.collectAsState()
        val analytics by viewModel.analytics.collectAsState()

        val schedules by viewModel.allSchedules.collectAsState()
        val etchTasks by viewModel.allEtchTasks.collectAsState()
        val employeeUsage by viewModel.allEmployeeUsage.collectAsState()
        val isAuthorityUnlocked by viewModel.isAuthorityModeActive.collectAsState()
        val isOnline by viewModel.isOnline.collectAsState()
        val cloudSyncStatus by viewModel.cloudSyncStatus.collectAsState()

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                KavishreeTopBar(
                    activeStaff = activeStaff,
                    isDarkMode = isDarkMode,
                    onToggleDarkMode = { viewModel.toggleDarkMode() },
                    onOpenSettings = { showSettingsDialog = true },
                    onSwitchStaff = { showStaffSwitchDialog = true }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    MainTab.values().forEach { tab ->
                        val isSelected = currentTab == tab
                        val icon = when (tab) {
                            MainTab.BILLING -> Icons.Default.PointOfSale
                            MainTab.BILLS_HISTORY -> Icons.Default.ReceiptLong
                            MainTab.INVENTORY -> Icons.Default.Inventory
                            MainTab.WORK_BASE -> Icons.Default.Assignment
                            MainTab.STAFF -> Icons.Default.Group
                            MainTab.ANALYTICS -> Icons.Default.Analytics
                        }

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentTab = tab },
                            icon = { Icon(imageVector = icon, contentDescription = tab.title) },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                indicatorColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                Crossfade(targetState = currentTab, label = "tab_transition") { tab ->
                    when (tab) {
                        MainTab.BILLING -> BillingPosScreen(
                            beverages = filteredBeverages,
                            allBeveragesForScanner = allBeverages,
                            cartItems = cartItems,
                            cartSubtotal = cartSubtotal,
                            activeStaff = activeStaff,
                            appSettings = appSettings,
                            selectedCategory = selectedCategory,
                            searchQuery = searchQuery,
                            onCategorySelected = { viewModel.setInventoryCategory(it) },
                            onSearchChanged = { viewModel.setSearchQuery(it) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onDecreaseCart = { viewModel.decreaseFromCart(it) },
                            onClearCart = { viewModel.clearCart() },
                            onSaveBill = { viewModel.saveCustomBill(it) }
                        )

                        MainTab.BILLS_HISTORY -> BillsHistoryScreen(
                            bills = filteredBills,
                            staffList = allStaff,
                            selectedStaffId = selectedStaffFilter,
                            selectedTimeRange = selectedTimeRange,
                            selectedPaymentStatus = selectedPaymentStatus,
                            appSettings = appSettings,
                            onSelectStaffFilter = { viewModel.staffFilter.value = it },
                            onSelectTimeRange = { viewModel.timeFilter.value = it },
                            onSelectPaymentStatusFilter = { viewModel.paymentStatusFilter.value = it },
                            onUpdatePaymentStatus = { billId, status -> viewModel.updateBillPaymentStatus(billId, status) },
                            onUpdateBillQrCode = { billId, hasQr -> viewModel.updateBillQrCode(billId, hasQr) },
                            onRemoveBill = { viewModel.removeBill(it) }
                        )

                        MainTab.INVENTORY -> InventoryScreen(
                            beverages = filteredBeverages,
                            selectedCategory = selectedCategory,
                            searchQuery = searchQuery,
                            onCategorySelected = { viewModel.setInventoryCategory(it) },
                            onSearchChanged = { viewModel.setSearchQuery(it) },
                            onAddBeverage = { name, cat, price, stock, unit, barcode, isSoda, desc ->
                                viewModel.addBeverageItem(name, cat, price, stock, unit, barcode, isSoda, desc)
                            },
                            onUpdatePriceAndStock = { id, price, stock ->
                                viewModel.updateBeveragePriceAndStock(id, price, stock)
                            },
                            onUpdateBeverageItem = { viewModel.updateBeverage(it) },
                            onRemoveBeverage = { viewModel.removeBeverageItem(it) }
                        )

                        MainTab.WORK_BASE -> WorkBaseScreen(
                            schedules = schedules,
                            etchTasks = etchTasks,
                            employeeUsage = employeeUsage,
                            staffList = allStaff,
                            beverages = allBeverages,
                            activeStaff = activeStaff,
                            isAuthorityUnlocked = isAuthorityUnlocked,
                            isOnline = isOnline,
                            cloudSyncStatus = cloudSyncStatus,
                            onVerifyAuthorityPin = { viewModel.verifyMasterAuthorityPin(it) },
                            onLockAuthority = { viewModel.revokeAuthorityMode() },
                            onToggleOnlineMode = { viewModel.toggleOnlineMode() },
                            onSyncNow = { viewModel.syncWithCloudNow() },
                            onAddSchedule = { staffId, staffName, date, type, station, notes ->
                                viewModel.addSchedule(staffId, staffName, date, type, station, notes)
                            },
                            onClockIn = { viewModel.clockInStaff(it) },
                            onClockOut = { viewModel.clockOutStaff(it) },
                            onDeleteSchedule = { viewModel.removeSchedule(it) },
                            onAddEtchTask = { title, station, desc, priority, staff ->
                                viewModel.addEtchTask(title, station, desc, priority, staff)
                            },
                            onToggleEtchCompleted = { task, staff ->
                                viewModel.toggleEtchTaskCompleted(task, staff)
                            },
                            onDeleteEtchTask = { viewModel.removeEtchTask(it) },
                            onLogEmployeeDrink = { staff, bev, reason, qty ->
                                viewModel.logEmployeeDrink(staff, bev, reason, qty)
                            },
                            onDeleteUsage = { viewModel.removeEmployeeDrinkUsage(it) }
                        )

                        MainTab.STAFF -> StaffScreen(
                            staffList = allStaff,
                            activeStaff = activeStaff,
                            onAddStaff = { id, name, role, phone, pin ->
                                viewModel.addStaffMember(id, name, role, phone, pin)
                            },
                            onRemoveStaff = { viewModel.removeStaffMember(it) },
                            onSwitchActiveStaff = { viewModel.quickSelectStaff(it) }
                        )

                        MainTab.ANALYTICS -> AnalyticsScreen(
                            analytics = analytics
                        )
                    }
                }
            }
        }
    }

    // Settings Dialog
    if (showSettingsDialog) {
        SettingsDialog(
            appSettings = appSettings,
            onSaveSettings = { upiId, payeeName, enableQr, phone, address, masterPin, isOnline ->
                viewModel.updateSettings(upiId, payeeName, enableQr, phone, address, masterPin, isOnline)
            },
            onDismiss = { showSettingsDialog = false }
        )
    }

    // Staff Switch Dialog
    if (showStaffSwitchDialog) {
        AlertDialog(
            onDismissRequest = { showStaffSwitchDialog = false },
            title = {
                Text(
                    text = "Switch Staff Session",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text("Do you want to switch current staff user or log out to the Staff Login screen?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.logout()
                        showStaffSwitchDialog = false
                    }
                ) {
                    Text("Logout to Login Screen", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showStaffSwitchDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
