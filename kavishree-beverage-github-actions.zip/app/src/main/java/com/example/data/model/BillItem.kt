package com.example.data.model

data class BillItem(
    val itemId: Long,
    val name: String,
    val price: Double,
    val quantity: Int,
    val unit: String = "Bottle",
    val isSoda: Boolean = false,
    val category: String = "Soda"
) {
    val lineTotal: Double
        get() = price * quantity
}
