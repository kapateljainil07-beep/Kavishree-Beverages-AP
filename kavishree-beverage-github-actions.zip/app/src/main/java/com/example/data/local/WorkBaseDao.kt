package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.EmployeeBeverageUsage
import com.example.data.model.EtchWorkTask
import com.example.data.model.StaffSchedule
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkBaseDao {
    // --- Staff Schedules ---
    @Query("SELECT * FROM staff_schedules ORDER BY createdAt DESC")
    fun getAllSchedules(): Flow<List<StaffSchedule>>

    @Query("SELECT * FROM staff_schedules WHERE staffId = :staffId ORDER BY createdAt DESC")
    fun getSchedulesForStaff(staffId: String): Flow<List<StaffSchedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: StaffSchedule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSchedules(schedules: List<StaffSchedule>)

    @Update
    suspend fun updateSchedule(schedule: StaffSchedule)

    @Delete
    suspend fun deleteSchedule(schedule: StaffSchedule)

    @Query("DELETE FROM staff_schedules WHERE id = :id")
    suspend fun deleteScheduleById(id: String)

    @Query("UPDATE staff_schedules SET status = :status, clockInTime = :clockIn WHERE id = :id")
    suspend fun clockIn(id: String, status: String = "On-Duty", clockIn: Long = System.currentTimeMillis())

    @Query("UPDATE staff_schedules SET status = :status, clockOutTime = :clockOut WHERE id = :id")
    suspend fun clockOut(id: String, status: String = "Completed", clockOut: Long = System.currentTimeMillis())

    // --- Etch Work Tasks ---
    @Query("SELECT * FROM etch_work_tasks ORDER BY isCompleted ASC, createdAt DESC")
    fun getAllEtchTasks(): Flow<List<EtchWorkTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEtchTask(task: EtchWorkTask)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllEtchTasks(tasks: List<EtchWorkTask>)

    @Update
    suspend fun updateEtchTask(task: EtchWorkTask)

    @Query("UPDATE etch_work_tasks SET isCompleted = :completed, completedByStaff = :staffName, completedAt = :timestamp WHERE id = :taskId")
    suspend fun markEtchTaskCompleted(taskId: String, completed: Boolean, staffName: String?, timestamp: Long?)

    @Query("DELETE FROM etch_work_tasks WHERE id = :taskId")
    suspend fun deleteEtchTaskById(taskId: String)

    // --- Employee Beverage Usage ---
    @Query("SELECT * FROM employee_beverage_usage ORDER BY timestamp DESC")
    fun getAllUsage(): Flow<List<EmployeeBeverageUsage>>

    @Query("SELECT * FROM employee_beverage_usage WHERE staffId = :staffId ORDER BY timestamp DESC")
    fun getUsageForStaff(staffId: String): Flow<List<EmployeeBeverageUsage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsage(usage: EmployeeBeverageUsage): Long

    @Query("DELETE FROM employee_beverage_usage WHERE id = :id")
    suspend fun deleteUsageById(id: Long)
}
