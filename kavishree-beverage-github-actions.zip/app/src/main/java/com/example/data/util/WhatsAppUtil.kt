package com.example.data.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.model.Bill
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WhatsAppUtil {

    fun formatBillMessage(bill: Bill, storeName: String, storeAddress: String): String {
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(bill.timestamp))
        val items = BillJsonUtil.fromJson(bill.itemsJson)

        val sb = StringBuilder()
        sb.append("🧾 *${storeName.uppercase()}*\n")
        sb.append("📍 $storeAddress\n")
        sb.append("━━━━━━━━━━━━━━━━━━━━\n")
        sb.append("📋 *Bill No:* #${bill.billId}\n")
        sb.append("📅 *Date:* $dateStr\n")
        sb.append("👤 *Billed By Staff:* ${bill.staffMemberName} (${bill.staffMemberId})\n")
        if (bill.customerName.isNotBlank()) {
            sb.append("🙋 *Customer:* ${bill.customerName}")
            if (bill.customerPhone.isNotBlank()) {
                sb.append(" (${bill.customerPhone})")
            }
            sb.append("\n")
        }
        sb.append("━━━━━━━━━━━━━━━━━━━━\n")
        sb.append("*ITEMS ORDERED:*\n")

        items.forEachIndexed { index, item ->
            val icon = if (item.isSoda) "🥤" else "🍹"
            sb.append("${index + 1}. $icon ${item.name} (${item.unit})\n")
            sb.append("   ${item.quantity} × ₹${String.format(Locale.US, "%.2f", item.price)} = *₹${String.format(Locale.US, "%.2f", item.lineTotal)}*\n")
        }

        sb.append("━━━━━━━━━━━━━━━━━━━━\n")
        sb.append("Subtotal: ₹${String.format(Locale.US, "%.2f", bill.subtotal)}\n")
        if (bill.discount > 0) {
            sb.append("Discount: -₹${String.format(Locale.US, "%.2f", bill.discount)}\n")
        }
        if (bill.tax > 0) {
            sb.append("Tax: +₹${String.format(Locale.US, "%.2f", bill.tax)}\n")
        }
        sb.append("💰 *PURCHASE AMOUNT / TOTAL: ₹${String.format(Locale.US, "%.2f", bill.totalAmount)}*\n")
        sb.append("💳 *Payment Method:* ${bill.paymentMethod} [${bill.paymentStatus}]\n")
        if (bill.notes.isNotBlank()) {
            sb.append("📝 *Payment Details:* ${bill.notes}\n")
        }

        if (bill.hasQrCode && bill.upiIdUsed.isNotBlank()) {
            sb.append("━━━━━━━━━━━━━━━━━━━━\n")
            sb.append("📲 *UPI Pay ID:* `${bill.upiIdUsed}`\n")
            val upiUri = "upi://pay?pa=${bill.upiIdUsed}&pn=${URLEncoder.encode(storeName, "UTF-8")}&am=${String.format(Locale.US, "%.2f", bill.totalAmount)}&cu=INR"
            sb.append("🔗 *Direct Pay Link:* $upiUri\n")
        }

        sb.append("━━━━━━━━━━━━━━━━━━━━\n")
        sb.append("🙏 *Thank you for your visit!*\n")
        sb.append("🥤 Best Quality Sodas & Fresh Beverages\n")

        return sb.toString()
    }

    fun sendBillViaWhatsApp(context: Context, bill: Bill, storeName: String, storeAddress: String) {
        val message = formatBillMessage(bill, storeName, storeAddress)
        val cleanedPhone = bill.customerPhone.replace(Regex("[^0-9]"), "")
        // If phone has 10 digits without country code, prepend India's +91
        val fullPhone = when {
            cleanedPhone.length == 10 -> "91$cleanedPhone"
            cleanedPhone.startsWith("0") && cleanedPhone.length == 11 -> "91" + cleanedPhone.substring(1)
            else -> cleanedPhone
        }

        try {
            val encodedMsg = URLEncoder.encode(message, "UTF-8")
            val uriString = if (fullPhone.isNotBlank()) {
                "https://api.whatsapp.com/send?phone=$fullPhone&text=$encodedMsg"
            } else {
                "https://api.whatsapp.com/send?text=$encodedMsg"
            }

            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to generic share
            try {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(Intent.createChooser(shareIntent, "Share Bill"))
            } catch (ex: Exception) {
                Toast.makeText(context, "Could not open WhatsApp or sharing app", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
