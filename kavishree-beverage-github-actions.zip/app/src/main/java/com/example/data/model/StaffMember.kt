package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "staff_members")
data class StaffMember(
    @PrimaryKey
    val id: String, // e.g. "STAFF-01", "ADMIN-01"
    val name: String,
    val role: String, // "Admin", "Cashier", "Server", "Manager"
    val phone: String,
    val pin: String = "1234",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
