package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey
    val id: Int = 1,
    val upiId: String = "kavishreebeverage@upi",
    val payeeName: String = "Kavishree Beverage",
    val enableQrOnBill: Boolean = true,
    val storePhone: String = "+91 9876543210",
    val storeAddress: String = "Kavishree Beverage & Soda Hub",
    val isDarkMode: Boolean = false,
    val activeStaffId: String? = null,
    val isOnline: Boolean = true,
    val masterAuthorityPin: String = "9999",
    val cloudSyncToken: String = "KB-SYNC-CLOUD-7788",
    val lastSyncTimestamp: Long = System.currentTimeMillis()
)
