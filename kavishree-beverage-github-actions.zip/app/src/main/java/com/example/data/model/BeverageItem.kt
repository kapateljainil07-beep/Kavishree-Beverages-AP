package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "beverage_items")
data class BeverageItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String, // "Soda", "Cold Drink", "Juice", "Water", "Snack"
    val price: Double,
    val stockQuantity: Int,
    val unit: String = "Bottle", // "Bottle", "Glass", "Can", "Pack"
    val barcode: String = "",
    val isSoda: Boolean = false,
    val description: String = "",
    val isAvailable: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
