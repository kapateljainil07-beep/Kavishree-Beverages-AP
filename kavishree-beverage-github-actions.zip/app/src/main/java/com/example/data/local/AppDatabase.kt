package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.AppSettings
import com.example.data.model.BeverageItem
import com.example.data.model.Bill
import com.example.data.model.EmployeeBeverageUsage
import com.example.data.model.EtchWorkTask
import com.example.data.model.StaffMember
import com.example.data.model.StaffSchedule

@Database(
    entities = [
        BeverageItem::class,
        StaffMember::class,
        Bill::class,
        AppSettings::class,
        StaffSchedule::class,
        EtchWorkTask::class,
        EmployeeBeverageUsage::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun beverageDao(): BeverageDao
    abstract fun staffDao(): StaffDao
    abstract fun billDao(): BillDao
    abstract fun settingsDao(): SettingsDao
    abstract fun workBaseDao(): WorkBaseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kavishree_beverage_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
