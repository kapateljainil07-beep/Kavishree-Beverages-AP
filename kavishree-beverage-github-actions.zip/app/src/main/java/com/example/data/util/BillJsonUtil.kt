package com.example.data.util

import com.example.data.model.BillItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

object BillJsonUtil {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val listType = Types.newParameterizedType(List::class.java, BillItem::class.java)
    private val adapter = moshi.adapter<List<BillItem>>(listType)

    fun toJson(items: List<BillItem>): String {
        return try {
            adapter.toJson(items)
        } catch (e: Exception) {
            "[]"
        }
    }

    fun fromJson(json: String): List<BillItem> {
        return try {
            adapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
