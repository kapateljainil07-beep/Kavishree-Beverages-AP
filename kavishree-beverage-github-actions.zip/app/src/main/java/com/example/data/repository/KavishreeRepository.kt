package com.example.data.repository

import com.example.data.local.BeverageDao
import com.example.data.local.BillDao
import com.example.data.local.SettingsDao
import com.example.data.local.StaffDao
import com.example.data.local.WorkBaseDao
import com.example.data.model.AppSettings
import com.example.data.model.BeverageItem
import com.example.data.model.Bill
import com.example.data.model.BillItem
import com.example.data.model.EmployeeBeverageUsage
import com.example.data.model.EtchWorkTask
import com.example.data.model.StaffMember
import com.example.data.model.StaffSchedule
import com.example.data.util.BillJsonUtil
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.concurrent.TimeUnit

class KavishreeRepository(
    private val beverageDao: BeverageDao,
    private val staffDao: StaffDao,
    private val billDao: BillDao,
    private val settingsDao: SettingsDao,
    private val workBaseDao: WorkBaseDao
) {
    // --- Beverages ---
    val allBeverages: Flow<List<BeverageItem>> = beverageDao.getAllBeverages()
    val sodaBeverages: Flow<List<BeverageItem>> = beverageDao.getSodaBeverages()

    suspend fun insertBeverage(item: BeverageItem): Long = beverageDao.insertBeverage(item)
    suspend fun updateBeverage(item: BeverageItem) = beverageDao.updateBeverage(item)
    suspend fun deleteBeverage(item: BeverageItem) = beverageDao.deleteBeverage(item)
    suspend fun deleteBeverageById(id: Long) = beverageDao.deleteBeverageById(id)
    suspend fun updatePriceAndStock(id: Long, price: Double, stock: Int) =
        beverageDao.updatePriceAndStock(id, price, stock)
    suspend fun getBeverageByBarcode(barcode: String): BeverageItem? =
        beverageDao.getBeverageByBarcode(barcode)

    // --- Work Base & Employee Scheduling ---
    val allSchedules: Flow<List<StaffSchedule>> = workBaseDao.getAllSchedules()
    fun getSchedulesForStaff(staffId: String): Flow<List<StaffSchedule>> = workBaseDao.getSchedulesForStaff(staffId)
    suspend fun insertSchedule(schedule: StaffSchedule) = workBaseDao.insertSchedule(schedule)
    suspend fun updateSchedule(schedule: StaffSchedule) = workBaseDao.updateSchedule(schedule)
    suspend fun deleteSchedule(schedule: StaffSchedule) = workBaseDao.deleteSchedule(schedule)
    suspend fun deleteScheduleById(id: String) = workBaseDao.deleteScheduleById(id)
    suspend fun clockInStaff(scheduleId: String) = workBaseDao.clockIn(scheduleId)
    suspend fun clockOutStaff(scheduleId: String) = workBaseDao.clockOut(scheduleId)

    // --- Etch Work Base Tasks ---
    val allEtchTasks: Flow<List<EtchWorkTask>> = workBaseDao.getAllEtchTasks()
    suspend fun insertEtchTask(task: EtchWorkTask) = workBaseDao.insertEtchTask(task)
    suspend fun updateEtchTask(task: EtchWorkTask) = workBaseDao.updateEtchTask(task)
    suspend fun markEtchTaskCompleted(taskId: String, completed: Boolean, staffName: String?) =
        workBaseDao.markEtchTaskCompleted(taskId, completed, staffName, if (completed) System.currentTimeMillis() else null)
    suspend fun deleteEtchTaskById(taskId: String) = workBaseDao.deleteEtchTaskById(taskId)

    // --- Real-Time Employee Beverage Usage ---
    val allEmployeeUsage: Flow<List<EmployeeBeverageUsage>> = workBaseDao.getAllUsage()
    fun getUsageForStaff(staffId: String): Flow<List<EmployeeBeverageUsage>> = workBaseDao.getUsageForStaff(staffId)
    suspend fun logEmployeeUsage(staffId: String, staffName: String, beverage: BeverageItem, reason: String, quantity: Int = 1) {
        val usage = EmployeeBeverageUsage(
            staffId = staffId,
            staffName = staffName,
            beverageId = beverage.id,
            beverageName = beverage.name,
            quantity = quantity,
            reason = reason,
            timestamp = System.currentTimeMillis()
        )
        workBaseDao.insertUsage(usage)
        // Automatically deduct from stock for real-time inventory precision
        beverageDao.decrementStock(beverage.id, quantity)
    }
    suspend fun deleteUsageById(id: Long) = workBaseDao.deleteUsageById(id)

    // --- Staff ---
    val allStaff: Flow<List<StaffMember>> = staffDao.getAllStaff()
    suspend fun getStaffById(id: String): StaffMember? = staffDao.getStaffById(id)
    suspend fun insertStaff(staff: StaffMember) = staffDao.insertStaff(staff)
    suspend fun deleteStaff(staff: StaffMember) = staffDao.deleteStaff(staff)
    suspend fun deleteStaffById(id: String) = staffDao.deleteStaffById(id)

    // --- Bills ---
    val allBills: Flow<List<Bill>> = billDao.getAllBills()

    fun getBillsForStaff(staffId: String): Flow<List<Bill>> =
        billDao.getBillsForStaff(staffId)

    fun get7DaysBills(): Flow<List<Bill>> {
        val sevenDaysAgo = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7)
        return billDao.getBillsSince(sevenDaysAgo)
    }

    fun get7DaysBillsForStaff(staffId: String): Flow<List<Bill>> {
        val sevenDaysAgo = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7)
        return billDao.getBillsForStaffSince(staffId, sevenDaysAgo)
    }

    suspend fun saveBill(bill: Bill) {
        billDao.insertBill(bill)
        // Automatically decrement inventory stock
        val items = BillJsonUtil.fromJson(bill.itemsJson)
        for (item in items) {
            beverageDao.decrementStock(item.itemId, item.quantity)
        }
    }

    suspend fun deleteBill(bill: Bill) = billDao.deleteBill(bill)
    suspend fun deleteBillById(billId: String) = billDao.deleteBillById(billId)
    suspend fun updateBillPaymentStatus(billId: String, status: String) = billDao.updatePaymentStatus(billId, status)
    suspend fun updateBillQrCode(billId: String, hasQr: Boolean) = billDao.updateBillQrCode(billId, hasQr)

    // --- Settings ---
    val settings: Flow<AppSettings?> = settingsDao.getSettings()
    suspend fun getSettingsSync(): AppSettings? = settingsDao.getSettingsSync()
    suspend fun saveSettings(settings: AppSettings) = settingsDao.saveSettings(settings)
    suspend fun updateDarkMode(isDark: Boolean) = settingsDao.updateDarkMode(isDark)
    suspend fun updateActiveStaff(staffId: String?) = settingsDao.updateActiveStaffId(staffId)
    suspend fun updateEnableQrOnBill(enable: Boolean) = settingsDao.updateEnableQrOnBill(enable)

    // --- Default Seed Data ---
    suspend fun initializeDefaultDataIfEmpty() {
        // Check settings
        if (settingsDao.getSettingsSync() == null) {
            settingsDao.saveSettings(
                AppSettings(
                    id = 1,
                    upiId = "kavishreebeverage@upi",
                    payeeName = "Kavishree Beverage",
                    enableQrOnBill = true,
                    storePhone = "+91 9876543210",
                    storeAddress = "Shop 12, Station Road, Kavishree Beverage Hub",
                    isDarkMode = false,
                    activeStaffId = "STAFF-01"
                )
            )
        }

        // Check staff
        val staffList = staffDao.getAllStaff().firstOrNull()
        if (staffList.isNullOrEmpty()) {
            val defaults = listOf(
                StaffMember(
                    id = "ADMIN-01",
                    name = "Kavishree Owner",
                    role = "Admin",
                    phone = "+91 9820011223",
                    pin = "1111"
                ),
                StaffMember(
                    id = "STAFF-01",
                    name = "Rajesh Kumar",
                    role = "Cashier",
                    phone = "+91 9876543210",
                    pin = "1234"
                ),
                StaffMember(
                    id = "STAFF-02",
                    name = "Priya Sharma",
                    role = "Beverage Staff",
                    phone = "+91 9812345678",
                    pin = "2222"
                ),
                StaffMember(
                    id = "STAFF-03",
                    name = "Amit Verma",
                    role = "Counter Staff",
                    phone = "+91 9765432109",
                    pin = "3333"
                )
            )
            staffDao.insertAllStaff(defaults)
        }

        // Check beverages
        val items = beverageDao.getAllBeverages().firstOrNull()
        if (items.isNullOrEmpty()) {
            val sampleItems = listOf(
                // Sodas
                BeverageItem(
                    name = "Jeera Masala Soda",
                    category = "Soda",
                    price = 20.0,
                    stockQuantity = 120,
                    unit = "Bottle",
                    barcode = "SODA-01",
                    isSoda = true,
                    description = "Refreshing cumin spiced bubbly fizz soda"
                ),
                BeverageItem(
                    name = "Lemon Masala Soda",
                    category = "Soda",
                    price = 25.0,
                    stockQuantity = 95,
                    unit = "Bottle",
                    barcode = "SODA-02",
                    isSoda = true,
                    description = "Tangy citrus lemon fizz with rock salt and mint"
                ),
                BeverageItem(
                    name = "Blueberry Blast Soda",
                    category = "Soda",
                    price = 35.0,
                    stockQuantity = 75,
                    unit = "Glass",
                    barcode = "SODA-03",
                    isSoda = true,
                    description = "Sweet chilled wild blueberry sparkling punch"
                ),
                BeverageItem(
                    name = "Kala Khatta Soda",
                    category = "Soda",
                    price = 25.0,
                    stockQuantity = 80,
                    unit = "Glass",
                    barcode = "SODA-04",
                    isSoda = true,
                    description = "Traditional sweet-tangy black plum crushed soda"
                ),
                BeverageItem(
                    name = "Orange Fizz Soda",
                    category = "Soda",
                    price = 20.0,
                    stockQuantity = 110,
                    unit = "Bottle",
                    barcode = "SODA-05",
                    isSoda = true,
                    description = "Sparkling zesty orange carbonated beverage"
                ),
                BeverageItem(
                    name = "Club Soda Special",
                    category = "Soda",
                    price = 15.0,
                    stockQuantity = 150,
                    unit = "Bottle",
                    barcode = "SODA-06",
                    isSoda = true,
                    description = "Extra-carbonated crisp crystal clear soda"
                ),
                BeverageItem(
                    name = "Ginger Lime Punch Soda",
                    category = "Soda",
                    price = 30.0,
                    stockQuantity = 60,
                    unit = "Glass",
                    barcode = "SODA-07",
                    isSoda = true,
                    description = "Warm spicy ginger with cool fresh lime sparkle"
                ),
                BeverageItem(
                    name = "Green Apple Soda",
                    category = "Soda",
                    price = 35.0,
                    stockQuantity = 50,
                    unit = "Glass",
                    barcode = "SODA-08",
                    isSoda = true,
                    description = "Crisp Granny Smith tart bubbly soda"
                ),
                // Cold Drinks & Juices
                BeverageItem(
                    name = "Mango Alphonso Frooti/Juice",
                    category = "Juice",
                    price = 30.0,
                    stockQuantity = 85,
                    unit = "Bottle",
                    barcode = "JUI-01",
                    isSoda = false,
                    description = "Rich sweet pulpy mango nectar"
                ),
                BeverageItem(
                    name = "Chilled Cold Coffee",
                    category = "Cold Drink",
                    price = 45.0,
                    stockQuantity = 40,
                    unit = "Cup",
                    barcode = "DRK-01",
                    isSoda = false,
                    description = "Creamy thick iced coffee brew"
                ),
                BeverageItem(
                    name = "Mineral Water Chilled (1L)",
                    category = "Water",
                    price = 20.0,
                    stockQuantity = 200,
                    unit = "Bottle",
                    barcode = "WAT-01",
                    isSoda = false,
                    description = "Pure ozonized packaged drinking water"
                ),
                BeverageItem(
                    name = "Rose Milk Shake",
                    category = "Cold Drink",
                    price = 40.0,
                    stockQuantity = 35,
                    unit = "Glass",
                    barcode = "DRK-02",
                    isSoda = false,
                    description = "Fragrant Damascus rose flavored milk drink"
                ),
                // Water Box Items
                BeverageItem(
                    name = "Water Box (24 x 500ml Case)",
                    category = "Water Box",
                    price = 240.0,
                    stockQuantity = 80,
                    unit = "Box",
                    barcode = "WAT-BOX-24",
                    isSoda = false,
                    description = "Wholesale sealed case carton containing 24 chilled drinking water bottles (500ml)"
                ),
                BeverageItem(
                    name = "Water Box (12 x 1L Pack)",
                    category = "Water Box",
                    price = 200.0,
                    stockQuantity = 65,
                    unit = "Box",
                    barcode = "WAT-BOX-12",
                    isSoda = false,
                    description = "Heavy duty wholesale corrugated box of 12 x 1 Litre mineral water bottles"
                ),
                BeverageItem(
                    name = "Packaged Water 20L Dispenser Box/Jar",
                    category = "Water Box",
                    price = 80.0,
                    stockQuantity = 50,
                    unit = "Box/Jar",
                    barcode = "WAT-BOX-20L",
                    isSoda = false,
                    description = "20 Litre bulk refill dispenser box canister for water coolers and corporate orders"
                ),
                BeverageItem(
                    name = "Premium Soda Box (24 Cans Assorted)",
                    category = "Water Box",
                    price = 450.0,
                    stockQuantity = 40,
                    unit = "Box",
                    barcode = "SODA-BOX-24",
                    isSoda = true,
                    description = "24-can variety box featuring Jeera, Lemon, Blueberry & Kala Khatta sodas"
                )
            )
            beverageDao.insertAllBeverages(sampleItems)
        } else {
            // Ensure Water Box items are present even if previous beverages exist
            ensureWaterBoxItemsExist()
        }

        // Check and seed default Staff Schedules
        val existingSchedules = workBaseDao.getAllSchedules().firstOrNull()
        if (existingSchedules.isNullOrEmpty()) {
            val defaultSchedules = listOf(
                StaffSchedule(
                    id = "SCHED-101",
                    staffId = "ADMIN-01",
                    staffName = "Kavishree Owner",
                    shiftDate = "Today",
                    shiftType = "Full Day",
                    assignedStation = "Master Authority / Store Supervision",
                    dutyNotes = "Oversee daily etch work base, online cloud sync, cash register reconciliation",
                    status = "On-Duty",
                    clockInTime = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(4)
                ),
                StaffSchedule(
                    id = "SCHED-102",
                    staffId = "STAFF-01",
                    staffName = "Rajesh Kumar",
                    shiftDate = "Today",
                    shiftType = "Morning (08:00 - 14:00)",
                    assignedStation = "Station 1: Soda & Etch Dispenser",
                    dutyNotes = "Monitor carbonation pressure (4.2 Bar), blend Jeera & Lemon fizz batches",
                    status = "On-Duty",
                    clockInTime = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(3)
                ),
                StaffSchedule(
                    id = "SCHED-103",
                    staffId = "STAFF-02",
                    staffName = "Priya Sharma",
                    shiftDate = "Today",
                    shiftType = "Evening (14:00 - 20:00)",
                    assignedStation = "Station 3: POS Billing Desk",
                    dutyNotes = "Manage WhatsApp bills, Cash, Online and UPI QR payments with precision",
                    status = "Scheduled"
                ),
                StaffSchedule(
                    id = "SCHED-104",
                    staffId = "STAFF-03",
                    staffName = "Amit Verma",
                    shiftDate = "Today",
                    shiftType = "Night (20:00 - 23:30)",
                    assignedStation = "Station 2: Water Box & Dispatch",
                    dutyNotes = "Load delivery pallets, count 24-pack & 12-pack Water Boxes, seal carton crates",
                    status = "Scheduled"
                )
            )
            workBaseDao.insertAllSchedules(defaultSchedules)
        }

        // Check and seed Etch Work Base tasks
        val existingTasks = workBaseDao.getAllEtchTasks().firstOrNull()
        if (existingTasks.isNullOrEmpty()) {
            val defaultTasks = listOf(
                EtchWorkTask(
                    id = "ETCH-01",
                    title = "Soda Carbonation & Etch Pressure Check",
                    station = "Station 1: Soda & Etch Dispenser",
                    description = "Verify CO2 pressure valve is calibrated at 4.2 Bar for signature bubbly fizz",
                    priority = "High",
                    assignedStaffName = "Rajesh Kumar",
                    isCompleted = true,
                    completedByStaff = "Rajesh Kumar",
                    completedAt = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(2)
                ),
                EtchWorkTask(
                    id = "ETCH-02",
                    title = "Assemble & Stack 25 Water Boxes (24x500ml)",
                    station = "Station 2: Water Box & Dispatch",
                    description = "Pack wholesale corrugated carton boxes with sealed 500ml water bottles",
                    priority = "High",
                    assignedStaffName = "Amit Verma",
                    isCompleted = false
                ),
                EtchWorkTask(
                    id = "ETCH-03",
                    title = "Etch Custom Kavishree Glass Bottles Batch #4",
                    station = "Station 1: Soda & Etch Dispenser",
                    description = "Laser etch logo and volume markings on 60 reusable vintage soda bottles",
                    priority = "Normal",
                    assignedStaffName = "Rajesh Kumar",
                    isCompleted = false
                ),
                EtchWorkTask(
                    id = "ETCH-04",
                    title = "Restock 20L Water Dispenser Boxes",
                    station = "Station 2: Water Box & Dispatch",
                    description = "Inspect seals and sanitize refill valve taps on 15 dispenser canisters",
                    priority = "Routine",
                    assignedStaffName = "Amit Verma",
                    isCompleted = false
                ),
                EtchWorkTask(
                    id = "ETCH-05",
                    title = "Sanitize Soda Nozzles & POS Card Swiper",
                    station = "Station 3: POS Billing Desk",
                    description = "Clean tap spouts, test Online card gateway & dynamic UPI QR display screen",
                    priority = "Routine",
                    assignedStaffName = "Priya Sharma",
                    isCompleted = false
                )
            )
            workBaseDao.insertAllEtchTasks(defaultTasks)
        }

        // Check and seed sample Employee Beverage Usage
        val existingUsage = workBaseDao.getAllUsage().firstOrNull()
        if (existingUsage.isNullOrEmpty()) {
            workBaseDao.insertUsage(
                EmployeeBeverageUsage(
                    staffId = "STAFF-01",
                    staffName = "Rajesh Kumar",
                    beverageId = 1,
                    beverageName = "Jeera Masala Soda",
                    quantity = 1,
                    reason = "Shift Allowance",
                    timestamp = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(75)
                )
            )
            workBaseDao.insertUsage(
                EmployeeBeverageUsage(
                    staffId = "STAFF-02",
                    staffName = "Priya Sharma",
                    beverageId = 11,
                    beverageName = "Mineral Water Chilled (1L)",
                    quantity = 1,
                    reason = "Duty Break",
                    timestamp = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(30)
                )
            )
        }

        // Check if sample 7-day bills exist for demonstration
        val existingBills = billDao.getAllBills().firstOrNull()
        if (existingBills.isNullOrEmpty()) {
            val now = System.currentTimeMillis()
            val dayMs = TimeUnit.DAYS.toMillis(1)

            val sampleBills = listOf(
                Bill(
                    billId = "KB-1001",
                    staffMemberId = "STAFF-01",
                    staffMemberName = "Rajesh Kumar",
                    customerName = "Rahul Patel",
                    customerPhone = "+91 9876543210",
                    itemsJson = BillJsonUtil.toJson(
                        listOf(
                            BillItem(itemId = 1, name = "Jeera Masala Soda", price = 20.0, quantity = 3, isSoda = true),
                            BillItem(itemId = 2, name = "Lemon Masala Soda", price = 25.0, quantity = 2, isSoda = true)
                        )
                    ),
                    subtotal = 110.0,
                    totalAmount = 110.0,
                    paymentMethod = "UPI / QR",
                    paymentStatus = "Paid",
                    timestamp = now - (dayMs * 0.5).toLong()
                ),
                Bill(
                    billId = "KB-1002",
                    staffMemberId = "STAFF-01",
                    staffMemberName = "Rajesh Kumar",
                    customerName = "Vikram Singh",
                    customerPhone = "+91 9822233344",
                    itemsJson = BillJsonUtil.toJson(
                        listOf(
                            BillItem(itemId = 3, name = "Blueberry Blast Soda", price = 35.0, quantity = 2, isSoda = true),
                            BillItem(itemId = 11, name = "Mineral Water Chilled (1L)", price = 20.0, quantity = 1, isSoda = false)
                        )
                    ),
                    subtotal = 90.0,
                    totalAmount = 90.0,
                    paymentMethod = "Cash",
                    paymentStatus = "Paid",
                    timestamp = now - (dayMs * 1.5).toLong()
                ),
                Bill(
                    billId = "KB-1003",
                    staffMemberId = "STAFF-02",
                    staffMemberName = "Priya Sharma",
                    customerName = "Ananya Desai",
                    customerPhone = "+91 9898989898",
                    itemsJson = BillJsonUtil.toJson(
                        listOf(
                            BillItem(itemId = 4, name = "Kala Khatta Soda", price = 25.0, quantity = 4, isSoda = true),
                            BillItem(itemId = 9, name = "Mango Alphonso Frooti/Juice", price = 30.0, quantity = 2, isSoda = false)
                        )
                    ),
                    subtotal = 160.0,
                    totalAmount = 160.0,
                    paymentMethod = "UPI / QR",
                    paymentStatus = "Paid",
                    timestamp = now - (dayMs * 2.5).toLong()
                ),
                Bill(
                    billId = "KB-1004",
                    staffMemberId = "STAFF-02",
                    staffMemberName = "Priya Sharma",
                    customerName = "Karan Shah",
                    customerPhone = "+91 9711223344",
                    itemsJson = BillJsonUtil.toJson(
                        listOf(
                            BillItem(itemId = 5, name = "Orange Fizz Soda", price = 20.0, quantity = 5, isSoda = true)
                        )
                    ),
                    subtotal = 100.0,
                    totalAmount = 100.0,
                    paymentMethod = "UPI / QR",
                    paymentStatus = "Paid",
                    timestamp = now - (dayMs * 3.8).toLong()
                ),
                Bill(
                    billId = "KB-1005",
                    staffMemberId = "STAFF-03",
                    staffMemberName = "Amit Verma",
                    customerName = "Sneha Joshi",
                    customerPhone = "+91 9655443322",
                    itemsJson = BillJsonUtil.toJson(
                        listOf(
                            BillItem(itemId = 10, name = "Chilled Cold Coffee", price = 45.0, quantity = 2, isSoda = false),
                            BillItem(itemId = 6, name = "Club Soda Special", price = 15.0, quantity = 2, isSoda = true)
                        )
                    ),
                    subtotal = 120.0,
                    totalAmount = 120.0,
                    paymentMethod = "Cash",
                    paymentStatus = "Paid",
                    timestamp = now - (dayMs * 5.2).toLong()
                ),
                Bill(
                    billId = "KB-1006",
                    staffMemberId = "STAFF-01",
                    staffMemberName = "Rajesh Kumar",
                    customerName = "Manish Gupta",
                    customerPhone = "+91 9811002299",
                    itemsJson = BillJsonUtil.toJson(
                        listOf(
                            BillItem(itemId = 7, name = "Ginger Lime Punch Soda", price = 30.0, quantity = 3, isSoda = true),
                            BillItem(itemId = 8, name = "Green Apple Soda", price = 35.0, quantity = 2, isSoda = true)
                        )
                    ),
                    subtotal = 160.0,
                    totalAmount = 160.0,
                    paymentMethod = "UPI / QR",
                    paymentStatus = "Paid",
                    timestamp = now - (dayMs * 6.1).toLong()
                )
            )
            billDao.insertAllBills(sampleBills)
        }
    }

    suspend fun ensureWaterBoxItemsExist() {
        val existing = beverageDao.getAllBeverages().firstOrNull() ?: emptyList()
        val hasWaterBox = existing.any { it.category == "Water Box" || it.name.contains("Water Box", ignoreCase = true) }
        if (!hasWaterBox) {
            val waterBoxes = listOf(
                BeverageItem(
                    name = "Water Box (24 x 500ml Case)",
                    category = "Water Box",
                    price = 240.0,
                    stockQuantity = 80,
                    unit = "Box",
                    barcode = "WAT-BOX-24",
                    isSoda = false,
                    description = "Wholesale sealed case carton containing 24 chilled drinking water bottles (500ml)"
                ),
                BeverageItem(
                    name = "Water Box (12 x 1L Pack)",
                    category = "Water Box",
                    price = 200.0,
                    stockQuantity = 65,
                    unit = "Box",
                    barcode = "WAT-BOX-12",
                    isSoda = false,
                    description = "Heavy duty wholesale corrugated box of 12 x 1 Litre mineral water bottles"
                ),
                BeverageItem(
                    name = "Packaged Water 20L Dispenser Box/Jar",
                    category = "Water Box",
                    price = 80.0,
                    stockQuantity = 50,
                    unit = "Box/Jar",
                    barcode = "WAT-BOX-20L",
                    isSoda = false,
                    description = "20 Litre bulk refill dispenser box canister for water coolers and corporate orders"
                ),
                BeverageItem(
                    name = "Premium Soda Box (24 Cans Assorted)",
                    category = "Water Box",
                    price = 450.0,
                    stockQuantity = 40,
                    unit = "Box",
                    barcode = "SODA-BOX-24",
                    isSoda = true,
                    description = "24-can variety box featuring Jeera, Lemon, Blueberry & Kala Khatta sodas"
                )
            )
            beverageDao.insertAllBeverages(waterBoxes)
        }
    }
}
