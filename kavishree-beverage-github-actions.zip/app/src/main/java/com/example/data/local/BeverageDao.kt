package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BeverageItem
import kotlinx.coroutines.flow.Flow

@Dao
interface BeverageDao {
    @Query("SELECT * FROM beverage_items WHERE isAvailable = 1 ORDER BY isSoda DESC, name ASC")
    fun getAllBeverages(): Flow<List<BeverageItem>>

    @Query("SELECT * FROM beverage_items WHERE isSoda = 1 AND isAvailable = 1 ORDER BY name ASC")
    fun getSodaBeverages(): Flow<List<BeverageItem>>

    @Query("SELECT * FROM beverage_items WHERE id = :id")
    suspend fun getBeverageById(id: Long): BeverageItem?

    @Query("SELECT * FROM beverage_items WHERE barcode = :barcode LIMIT 1")
    suspend fun getBeverageByBarcode(barcode: String): BeverageItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBeverage(item: BeverageItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllBeverages(items: List<BeverageItem>)

    @Update
    suspend fun updateBeverage(item: BeverageItem)

    @Delete
    suspend fun deleteBeverage(item: BeverageItem)

    @Query("DELETE FROM beverage_items WHERE id = :id")
    suspend fun deleteBeverageById(id: Long)

    @Query("UPDATE beverage_items SET price = :price, stockQuantity = :stock WHERE id = :id")
    suspend fun updatePriceAndStock(id: Long, price: Double, stock: Int)

    @Query("UPDATE beverage_items SET stockQuantity = CASE WHEN stockQuantity >= :quantity THEN stockQuantity - :quantity ELSE 0 END WHERE id = :id")
    suspend fun decrementStock(id: Long, quantity: Int)
}
