package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.Bill
import kotlinx.coroutines.flow.Flow

@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY timestamp DESC")
    fun getAllBills(): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE staffMemberId = :staffId ORDER BY timestamp DESC")
    fun getBillsForStaff(staffId: String): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE timestamp >= :sinceTimestamp ORDER BY timestamp DESC")
    fun getBillsSince(sinceTimestamp: Long): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE staffMemberId = :staffId AND timestamp >= :sinceTimestamp ORDER BY timestamp DESC")
    fun getBillsForStaffSince(staffId: String, sinceTimestamp: Long): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE billId = :billId LIMIT 1")
    suspend fun getBillById(billId: String): Bill?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: Bill)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllBills(bills: List<Bill>)

    @Delete
    suspend fun deleteBill(bill: Bill)

    @Query("DELETE FROM bills WHERE billId = :billId")
    suspend fun deleteBillById(billId: String)

    @Query("UPDATE bills SET paymentStatus = :status WHERE billId = :billId")
    suspend fun updatePaymentStatus(billId: String, status: String)

    @Query("UPDATE bills SET hasQrCode = :hasQr WHERE billId = :billId")
    suspend fun updateBillQrCode(billId: String, hasQr: Boolean)

    @Query("DELETE FROM bills")
    suspend fun deleteAllBills()
}
