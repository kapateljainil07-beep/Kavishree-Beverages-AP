package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "etch_work_tasks")
data class EtchWorkTask(
    @PrimaryKey
    val id: String, // e.g. "ETCH-01"
    val title: String,
    val station: String, // "Station 1: Soda & Etch Dispenser", "Station 2: Water Box & Dispatch", "Station 3: Drink Processing"
    val description: String,
    val priority: String = "Normal", // "High", "Normal", "Routine"
    val assignedStaffName: String = "Any Staff",
    val isCompleted: Boolean = false,
    val completedByStaff: String? = null,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
