package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "staff_schedules")
data class StaffSchedule(
    @PrimaryKey
    val id: String, // e.g. "SCHED-101"
    val staffId: String,
    val staffName: String,
    val shiftDate: String, // e.g. "2026-09-15" or "Today"
    val shiftType: String, // "Morning (08:00 - 14:00)", "Evening (14:00 - 20:00)", "Night (20:00 - 23:30)", "Full Day"
    val assignedStation: String, // "Station 1: Soda & Etch Dispenser", "Station 2: Water Box & Dispatch", "Station 3: POS Billing Desk", "Station 4: Juices & Drinks"
    val dutyNotes: String = "",
    val status: String = "Scheduled", // "Scheduled", "On-Duty", "Completed", "Absent"
    val clockInTime: Long? = null,
    val clockOutTime: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
