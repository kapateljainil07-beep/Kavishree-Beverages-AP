package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey
    val billId: String, // e.g. "KB-1001"
    val staffMemberId: String,
    val staffMemberName: String,
    val customerName: String,
    val customerPhone: String,
    val itemsJson: String,
    val subtotal: Double,
    val discount: Double = 0.0,
    val tax: Double = 0.0,
    val totalAmount: Double,
    val paymentMethod: String = "UPI / QR", // "UPI / QR", "Cash", "Card"
    val paymentStatus: String = "Paid", // "Paid", "Pending", "Cancelled"
    val hasQrCode: Boolean = true,
    val upiIdUsed: String = "kavishreebeverage@upi",
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
