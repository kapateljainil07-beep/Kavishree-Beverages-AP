package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "employee_beverage_usage")
data class EmployeeBeverageUsage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val staffId: String,
    val staffName: String,
    val beverageId: Long,
    val beverageName: String,
    val quantity: Int = 1,
    val reason: String = "Shift Allowance", // "Shift Allowance", "Tasting & Quality", "Duty Break"
    val timestamp: Long = System.currentTimeMillis()
)
