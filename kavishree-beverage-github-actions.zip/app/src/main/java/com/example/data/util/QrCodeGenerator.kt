package com.example.data.util

import kotlin.math.min

/**
 * Pure Kotlin QR Code Matrix Generator.
 * Implements standard QR Code symbol generation (Versions 1-6, Byte mode, Error Correction Level M/L).
 * Generates an exact 2D boolean matrix suitable for crisp Jetpack Compose Canvas rendering.
 */
object QrCodeGenerator {

    data class QrMatrix(val size: Int, val modules: Array<BooleanArray>) {
        operator fun get(row: Int, col: Int): Boolean = modules[row][col]

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is QrMatrix) return false
            return size == other.size && modules.contentDeepEquals(other.modules)
        }

        override fun hashCode(): Int {
            return 31 * size + modules.contentDeepHashCode()
        }
    }

    // Reed-Solomon Galois Field GF(256) with primitive polynomial 0x11D (285)
    private val expTable = IntArray(512)
    private val logTable = IntArray(256)

    init {
        var x = 1
        for (i in 0 until 255) {
            expTable[i] = x
            logTable[x] = i
            x = (x shl 1)
            if ((x and 0x100) != 0) {
                x = x xor 0x11D
            }
        }
        for (i in 255 until 512) {
            expTable[i] = expTable[i - 255]
        }
    }

    private fun gfMul(x: Int, y: Int): Int {
        if (x == 0 || y == 0) return 0
        return expTable[logTable[x] + logTable[y]]
    }

    private fun rsCompute(data: ByteArray, ecCount: Int): ByteArray {
        // Generator polynomial coefficients
        var gen = intArrayOf(1)
        for (i in 0 until ecCount) {
            val nextGen = IntArray(gen.size + 1)
            val root = expTable[i]
            for (j in gen.indices) {
                nextGen[j] = nextGen[j] xor gfMul(gen[j], root)
                nextGen[j + 1] = nextGen[j + 1] xor gen[j]
            }
            gen = nextGen
        }

        val res = IntArray(ecCount)
        for (b in data) {
            val factor = (b.toInt() and 0xFF) xor res[0]
            System.arraycopy(res, 1, res, 0, ecCount - 1)
            res[ecCount - 1] = 0
            for (j in 0 until ecCount) {
                res[j] = res[j] xor gfMul(gen[ecCount - j], factor)
            }
        }
        val out = ByteArray(ecCount)
        for (i in 0 until ecCount) out[i] = res[i].toByte()
        return out
    }

    fun encode(text: String): QrMatrix {
        val bytes = text.toByteArray(Charsets.UTF_8)
        // Choose suitable version:
        // V1: 17 data bytes (L) / 14 (M)
        // V2: 32 data bytes (L) / 26 (M)
        // V3: 53 data bytes (L) / 42 (M)
        // V4: 78 data bytes (L) / 62 (M)
        // V5: 106 data bytes (L) / 84 (M)
        // V6: 134 data bytes (L) / 106 (M)
        // V7: 154 data bytes (L) / 122 (M)
        val len = bytes.size
        val version = when {
            len <= 14 -> 1
            len <= 26 -> 2
            len <= 42 -> 3
            len <= 62 -> 4
            len <= 84 -> 5
            len <= 106 -> 6
            len <= 130 -> 7
            else -> 8
        }

        val size = version * 4 + 17
        val matrix = Array(size) { BooleanArray(size) }
        val reserved = Array(size) { BooleanArray(size) }

        fun setModule(r: Int, c: Int, isBlack: Boolean, isReserved: Boolean = true) {
            if (r in 0 until size && c in 0 until size) {
                matrix[r][c] = isBlack
                if (isReserved) reserved[r][c] = true
            }
        }

        // Draw 7x7 Finder Pattern with 1px separator
        fun drawFinder(top: Int, left: Int) {
            for (r in 0..6) {
                for (c in 0..6) {
                    val isBlack = (r == 0 || r == 6 || c == 0 || c == 6 || (r in 2..4 && c in 2..4))
                    setModule(top + r, left + c, isBlack)
                }
            }
            // Separator
            for (r in -1..7) {
                for (c in -1..7) {
                    val tr = top + r
                    val tc = left + c
                    if (tr in 0 until size && tc in 0 until size) {
                        if (r == -1 || r == 7 || c == -1 || c == 7) {
                            setModule(tr, tc, false)
                        }
                    }
                }
            }
        }

        drawFinder(0, 0)
        drawFinder(0, size - 7)
        drawFinder(size - 7, 0)

        // Alignment patterns for version >= 2
        if (version >= 2) {
            val alignPos = when (version) {
                2 -> intArrayOf(6, 18)
                3 -> intArrayOf(6, 22)
                4 -> intArrayOf(6, 26)
                5 -> intArrayOf(6, 30)
                6 -> intArrayOf(6, 34)
                7 -> intArrayOf(6, 22, 38)
                else -> intArrayOf(6, 24, 42)
            }
            for (r in alignPos) {
                for (c in alignPos) {
                    if (reserved[r][c]) continue
                    for (dr in -2..2) {
                        for (dc in -2..2) {
                            val isBlack = (dr == -2 || dr == 2 || dc == -2 || dc == 2 || (dr == 0 && dc == 0))
                            setModule(r + dr, c + dc, isBlack)
                        }
                    }
                }
            }
        }

        // Timing patterns
        for (i in 8 until size - 8) {
            val isBlack = (i % 2 == 0)
            if (!reserved[6][i]) setModule(6, i, isBlack)
            if (!reserved[i][6]) setModule(i, 6, isBlack)
        }

        // Dark module
        setModule(size - 8, 8, true)

        // Reserve format info areas
        for (i in 0..8) {
            if (i != 6) {
                if (!reserved[8][i]) setModule(8, i, false)
                if (!reserved[i][8]) setModule(i, 8, false)
            }
        }
        for (i in size - 8 until size) {
            if (!reserved[8][i]) setModule(8, i, false)
            if (!reserved[i][8]) setModule(i, 8, false)
        }

        // Data payload assembly
        // Mode 0100 (Byte mode) + 8-bit count
        val bitBuffer = mutableListOf<Boolean>()
        fun addBits(value: Int, count: Int) {
            for (i in count - 1 downTo 0) {
                bitBuffer.add(((value shr i) and 1) == 1)
            }
        }

        addBits(4, 4) // 0100 Byte mode
        addBits(bytes.size, 8)
        for (b in bytes) {
            addBits(b.toInt() and 0xFF, 8)
        }

        // Capacity table (EC Level M)
        val dataCapacityBytes = when (version) {
            1 -> 16
            2 -> 28
            3 -> 44
            4 -> 64
            5 -> 86
            6 -> 108
            7 -> 124
            else -> 154
        }
        val ecBytesCount = when (version) {
            1 -> 10
            2 -> 16
            3 -> 26
            4 -> 18 * 2
            5 -> 24 * 2
            6 -> 16 * 4
            7 -> 18 * 4
            else -> 22 * 4
        }

        // Terminator up to 4 bits
        val totalDataBits = dataCapacityBytes * 8
        val padZeros = min(4, totalDataBits - bitBuffer.size)
        for (i in 0 until padZeros) bitBuffer.add(false)
        while (bitBuffer.size % 8 != 0) bitBuffer.add(false)

        // Pad bytes 0xEC and 0x11
        val padPatterns = intArrayOf(0xEC, 0x11)
        var padIdx = 0
        while (bitBuffer.size < totalDataBits) {
            addBits(padPatterns[padIdx % 2], 8)
            padIdx++
        }

        val dataBytes = ByteArray(dataCapacityBytes)
        for (i in 0 until dataCapacityBytes) {
            var b = 0
            for (j in 0 until 8) {
                if (bitBuffer[i * 8 + j]) b = b or (1 shl (7 - j))
            }
            dataBytes[i] = b.toByte()
        }

        val ecBytes = rsCompute(dataBytes, ecBytesCount)
        val allCodewords = dataBytes + ecBytes

        // Place data into matrix in zigzag 2-column fashion
        var bitIndex = 0
        val totalBits = allCodewords.size * 8
        var upward = true
        var col = size - 1
        while (col > 0) {
            if (col == 6) col-- // skip vertical timing line
            val rows = if (upward) (size - 1 downTo 0) else (0 until size)
            for (row in rows) {
                for (c in 0..1) {
                    val targetCol = col - c
                    if (!reserved[row][targetCol]) {
                        var bit = false
                        if (bitIndex < totalBits) {
                            val byteIdx = bitIndex / 8
                            val bitInByte = 7 - (bitIndex % 8)
                            bit = ((allCodewords[byteIdx].toInt() shr bitInByte) and 1) == 1
                            bitIndex++
                        }
                        // Apply Mask Pattern 0: (row + col) % 2 == 0
                        val mask = ((row + targetCol) % 2 == 0)
                        matrix[row][targetCol] = bit xor mask
                    }
                }
            }
            upward = !upward
            col -= 2
        }

        // Write Format Information (Mask 0, EC level M = 00)
        // Format bits with BCH: 101010000010010 (BCH 15,5 code for 00 000 with mask 101010000010010)
        val formatBits = booleanArrayOf(
            true, false, true, false, true, false, false, false,
            false, false, true, false, false, true, false
        )

        val formatCoords = arrayOf(
            // Top-left
            intArrayOf(8, 0), intArrayOf(8, 1), intArrayOf(8, 2), intArrayOf(8, 3),
            intArrayOf(8, 4), intArrayOf(8, 5), intArrayOf(8, 7), intArrayOf(8, 8),
            intArrayOf(7, 8), intArrayOf(5, 8), intArrayOf(4, 8), intArrayOf(3, 8),
            intArrayOf(2, 8), intArrayOf(1, 8), intArrayOf(0, 8)
        )
        for (i in formatCoords.indices) {
            val r = formatCoords[i][0]
            val c = formatCoords[i][1]
            matrix[r][c] = formatBits[i]
        }

        // Second format copy
        for (i in 0..7) {
            matrix[8][size - 1 - i] = formatBits[i]
        }
        for (i in 0..6) {
            matrix[size - 7 + i][8] = formatBits[8 + i]
        }

        return QrMatrix(size, matrix)
    }
}
